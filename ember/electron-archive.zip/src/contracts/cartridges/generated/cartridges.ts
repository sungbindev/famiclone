// 由 tools/schema-gen/schema-gen.mjs 根据 schema/cartridges.schema.json 生成，不要手改。
/* eslint-disable */


import type { ModuleSchema } from '../../../shared/schema/schema-types';
import type { CartridgeSummary } from '../../runtime/generated/runtime';
import type { RuntimeState } from '../../runtime/generated/runtime';

/** 最近打开的清单里的一项：给界面看的显示名与编号，不含路径。 */
export interface RecentCartridge {
  /** 编号：本次运行内有效，用于 openRecent */
  id: number;
  /** 显示名：文件名 */
  name: string;
}

/** 加载完成的卡带与加载后的运行状态。 */
export interface LoadedCartridge {
  cartridge: CartridgeSummary;
  state: RuntimeState;
}

export interface CartridgesLoadParams {
  /** NES 文件的路径，由主进程根据用户选择的文件给出 */
  path: string;
  /** 装入后是否上电，默认 true */
  powerOn?: boolean;
  /** 上电后是否直接运行，默认 true；powerOn 为 false 时无效 */
  resume?: boolean;
}

export interface CartridgesLoadResult {
  cartridge: CartridgeSummary;
  state: RuntimeState;
}

export type CartridgesEjectParams = Record<string, never>;

export interface CartridgesEjectResult {
  state: RuntimeState;
}

export type CartridgesInfoParams = Record<string, never>;

export interface CartridgesInfoResult {
  cartridge: CartridgeSummary;
}

export interface CartridgesOpenParams {
  /** 拖入窗口的文件的编号（拖放时由主进程登记，路径只在主进程里）；不给时弹出文件选择窗口 */
  droppedId?: number;
}

export interface CartridgesOpenResult {
  /** 用户是否取消了选择 */
  canceled: boolean;
  /** 加载结果；取消时没有这一项 */
  loaded?: LoadedCartridge;
}

export type CartridgesRecentParams = Record<string, never>;

export interface CartridgesRecentResult {
  /** 清单，最近的在前 */
  items: RecentCartridge[];
}

export interface CartridgesOpenRecentParams {
  /** recent 给出的编号 */
  id: number;
}

export interface CartridgesOpenRecentResult {
  /** 加载结果 */
  loaded: LoadedCartridge;
}

export interface CartridgesLoadedData {
  cartridge: CartridgeSummary;
}

/** 本模块的请求名。 */
export const CARTRIDGES_REQUESTS = {
  load: 'cartridges.load',
  eject: 'cartridges.eject',
  info: 'cartridges.info'
} as const;

/** 本模块由主进程处理的请求名。 */
export const CARTRIDGES_MAIN_REQUESTS = {
  open: 'cartridges.open',
  recent: 'cartridges.recent',
  openRecent: 'cartridges.openRecent'
} as const;

/** 本模块的事件名。 */
export const CARTRIDGES_EVENTS = {
  loaded: 'cartridges.loaded'
} as const;

/** 请求名到参数与结果类型的对照。 */
export interface CartridgesRequestMap {
  'cartridges.load': { params: CartridgesLoadParams; result: CartridgesLoadResult };
  'cartridges.eject': { params: CartridgesEjectParams; result: CartridgesEjectResult };
  'cartridges.info': { params: CartridgesInfoParams; result: CartridgesInfoResult };
}

/** 主进程处理的请求名到参数与结果类型的对照。 */
export interface CartridgesMainRequestMap {
  'cartridges.open': { params: CartridgesOpenParams; result: CartridgesOpenResult };
  'cartridges.recent': { params: CartridgesRecentParams; result: CartridgesRecentResult };
  'cartridges.openRecent': { params: CartridgesOpenRecentParams; result: CartridgesOpenRecentResult };
}

/** 事件名到数据类型的对照。 */
export interface CartridgesEventMap {
  'cartridges.loaded': CartridgesLoadedData;
}

/** 本模块的 Schema，供入口校验使用。 */
export const CARTRIDGES_SCHEMA: ModuleSchema = {
  "module": "cartridges",
  "types": {
    "RecentCartridge": {
      "type": "object",
      "description": "最近打开的清单里的一项：给界面看的显示名与编号，不含路径。",
      "properties": {
        "id": {
          "type": "integer",
          "minimum": 1,
          "description": "编号：本次运行内有效，用于 openRecent"
        },
        "name": {
          "type": "string",
          "description": "显示名：文件名"
        }
      },
      "required": [
        "id",
        "name"
      ]
    },
    "LoadedCartridge": {
      "type": "object",
      "description": "加载完成的卡带与加载后的运行状态。",
      "properties": {
        "cartridge": {
          "$ref": "runtime#/types/CartridgeSummary"
        },
        "state": {
          "$ref": "runtime#/types/RuntimeState"
        }
      },
      "required": [
        "cartridge",
        "state"
      ]
    }
  },
  "requests": {
    "load": {
      "description": "读取 NES 文件，解析文件头，按 mapper 号与变体匹配插件，装配主机并插入卡槽；已有的卡带与主机被替换，失败时原有的保持不变。匹配失败的错误码是 mappers.noMatch、mappers.conflict、mappers.hostUnknown，插件加载失败的是 mappers.notFound、mappers.invalidPackage、mappers.limitExceeded。",
      "mainOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "path": {
            "type": "string",
            "minLength": 1,
            "description": "NES 文件的路径，由主进程根据用户选择的文件给出"
          },
          "powerOn": {
            "type": "boolean",
            "description": "装入后是否上电，默认 true"
          },
          "resume": {
            "type": "boolean",
            "description": "上电后是否直接运行，默认 true；powerOn 为 false 时无效"
          }
        },
        "required": [
          "path"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "cartridge": {
            "$ref": "runtime#/types/CartridgeSummary"
          },
          "state": {
            "$ref": "runtime#/types/RuntimeState"
          }
        },
        "required": [
          "cartridge",
          "state"
        ]
      },
      "errors": [
        "cartridges.fileNotFound",
        "cartridges.fileUnreadable",
        "cartridges.notInes",
        "cartridges.truncated",
        "cartridges.unsupportedFormat",
        "cartridges.invalidHeader"
      ]
    },
    "eject": {
      "description": "取出卡带：主机随之拆除，电源状态变为断电；没有卡带时没有效果。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "state": {
            "$ref": "runtime#/types/RuntimeState"
          }
        },
        "required": [
          "state"
        ]
      },
      "errors": []
    },
    "info": {
      "description": "当前卡带的描述、匹配到的插件与存储区清单。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "cartridge": {
            "$ref": "runtime#/types/CartridgeSummary"
          }
        },
        "required": [
          "cartridge"
        ]
      },
      "errors": [
        "cartridges.empty"
      ]
    }
  },
  "mainRequests": {
    "open": {
      "description": "弹出系统文件选择窗口（只显示 .nes），把用户选定的文件交给 cartridges.load；用户取消选择时 canceled 为 true，不是错误。给出 droppedId 时不弹窗口，直接用拖入窗口的那个文件。",
      "params": {
        "type": "object",
        "properties": {
          "droppedId": {
            "type": "integer",
            "minimum": 1,
            "description": "拖入窗口的文件的编号（拖放时由主进程登记，路径只在主进程里）；不给时弹出文件选择窗口"
          }
        },
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "canceled": {
            "type": "boolean",
            "description": "用户是否取消了选择"
          },
          "loaded": {
            "$ref": "#/types/LoadedCartridge",
            "description": "加载结果；取消时没有这一项"
          }
        },
        "required": [
          "canceled"
        ]
      },
      "errors": [
        "cartridges.droppedNotFound",
        "cartridges.fileNotFound",
        "cartridges.fileUnreadable",
        "cartridges.notInes",
        "cartridges.truncated",
        "cartridges.unsupportedFormat",
        "cartridges.invalidHeader"
      ]
    },
    "recent": {
      "description": "最近打开的卡带清单（最近的在前，最多 10 个）：只给显示名与本次运行内有效的编号，路径只保存在主进程；打开卡带成功之前就已记入清单，加载失败的会被移出。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "items": {
            "type": "array",
            "items": {
              "$ref": "#/types/RecentCartridge"
            },
            "description": "清单，最近的在前"
          }
        },
        "required": [
          "items"
        ]
      },
      "errors": []
    },
    "openRecent": {
      "description": "重新打开最近打开清单里的一个卡带：按编号取出路径交给 cartridges.load（powerOn、resume 都用默认值）；加载失败的卡带会从清单里移出。",
      "params": {
        "type": "object",
        "properties": {
          "id": {
            "type": "integer",
            "minimum": 1,
            "description": "recent 给出的编号"
          }
        },
        "required": [
          "id"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "loaded": {
            "$ref": "#/types/LoadedCartridge",
            "description": "加载结果"
          }
        },
        "required": [
          "loaded"
        ]
      },
      "errors": [
        "cartridges.recentNotFound",
        "cartridges.fileNotFound",
        "cartridges.fileUnreadable",
        "cartridges.notInes",
        "cartridges.truncated",
        "cartridges.unsupportedFormat",
        "cartridges.invalidHeader"
      ]
    }
  },
  "events": {
    "loaded": {
      "description": "卡带装配完成。",
      "data": {
        "type": "object",
        "properties": {
          "cartridge": {
            "$ref": "runtime#/types/CartridgeSummary"
          }
        },
        "required": [
          "cartridge"
        ]
      }
    }
  }
};
