// 由 tools/schema-gen/schema-gen.mjs 根据 schema/ 下全部模块 生成，不要手改。
/* eslint-disable */


import type { ModuleSchema } from '../../../shared/schema/schema-types';
import { CARTRIDGES_SCHEMA, type CartridgesEventMap, type CartridgesMainRequestMap, type CartridgesRequestMap } from '../../cartridges/generated/cartridges';
import { DEBUG_SCHEMA, type DebugEventMap, type DebugMainRequestMap, type DebugRequestMap } from '../../debug/generated/debug';
import { INPUT_SCHEMA, type InputEventMap, type InputMainRequestMap, type InputRequestMap } from '../../input/generated/input';
import { INSPECTOR_SCHEMA, type InspectorEventMap, type InspectorMainRequestMap, type InspectorRequestMap } from '../../inspector/generated/inspector';
import { MACHINES_SCHEMA, type MachinesEventMap, type MachinesMainRequestMap, type MachinesRequestMap } from '../../machines/generated/machines';
import { MAPPERS_SCHEMA, type MappersEventMap, type MappersMainRequestMap, type MappersRequestMap } from '../../mappers/generated/mappers';
import { MEDIA_SCHEMA, type MediaEventMap, type MediaMainRequestMap, type MediaRequestMap } from '../../media/generated/media';
import { OUTPUT_SCHEMA, type OutputEventMap, type OutputMainRequestMap, type OutputRequestMap } from '../../output/generated/output';
import { PREFERENCES_SCHEMA, type PreferencesEventMap, type PreferencesMainRequestMap, type PreferencesRequestMap } from '../../preferences/generated/preferences';
import { RUNTIME_SCHEMA, type RuntimeEventMap, type RuntimeMainRequestMap, type RuntimeRequestMap } from '../../runtime/generated/runtime';
import { SYSTEM_SCHEMA, type SystemEventMap, type SystemMainRequestMap, type SystemRequestMap } from '../../system/generated/system';

/** 全部请求名到参数与结果类型的对照。 */
export type CoreRequestMap = CartridgesRequestMap & DebugRequestMap & InputRequestMap & InspectorRequestMap & MachinesRequestMap & MappersRequestMap & MediaRequestMap & OutputRequestMap & PreferencesRequestMap & RuntimeRequestMap & SystemRequestMap;

/** 全部主进程处理的请求名到参数与结果类型的对照。 */
export type MainRequestMap = CartridgesMainRequestMap & DebugMainRequestMap & InputMainRequestMap & InspectorMainRequestMap & MachinesMainRequestMap & MappersMainRequestMap & MediaMainRequestMap & OutputMainRequestMap & PreferencesMainRequestMap & RuntimeMainRequestMap & SystemMainRequestMap;

/** 全部事件名到数据类型的对照。 */
export type CoreEventMap = CartridgesEventMap & DebugEventMap & InputEventMap & InspectorEventMap & MachinesEventMap & MappersEventMap & MediaEventMap & OutputEventMap & PreferencesEventMap & RuntimeEventMap & SystemEventMap;

/** 请求名。 */
export type CoreRequestName = keyof CoreRequestMap & string;
/** 事件名。 */
export type CoreEventName = keyof CoreEventMap & string;
/** 请求的参数类型。 */
export type CoreParams<N extends CoreRequestName> = CoreRequestMap[N] extends { params: infer P } ? P : never;
/** 请求的结果类型。 */
export type CoreResult<N extends CoreRequestName> = CoreRequestMap[N] extends { result: infer R } ? R : never;
/** 事件的数据类型。 */
export type CoreEventData<N extends CoreEventName> = CoreEventMap[N];
/** 主进程处理的请求名。 */
export type MainRequestName = keyof MainRequestMap & string;
/** 主进程处理的请求的参数类型。 */
export type MainParams<N extends MainRequestName> = MainRequestMap[N] extends { params: infer P } ? P : never;
/** 主进程处理的请求的结果类型。 */
export type MainResult<N extends MainRequestName> = MainRequestMap[N] extends { result: infer R } ? R : never;

/** 界面可以发起的请求名；只能由主进程发起与只经调试服务开放的请求不在其中。 */
export const CORE_REQUEST_NAMES: readonly string[] = [
  'cartridges.eject',
  'cartridges.info',
  'debug.status',
  'input.getBindings',
  'input.setBindings',
  'input.resetBindings',
  'machines.list',
  'machines.removeBios',
  'machines.boot',
  'mappers.list',
  'mappers.info',
  'mappers.uninstall',
  'mappers.setEnabled',
  'mappers.reload',
  'media.floppyEject',
  'media.floppySave',
  'media.floppyWriteProtect',
  'media.floppyStatus',
  'media.printerStatus',
  'media.printerFlush',
  'media.tapeEject',
  'media.tapePlay',
  'media.tapeStop',
  'media.tapeStatus',
  'output.setVolume',
  'preferences.list',
  'preferences.set',
  'preferences.reset',
  'runtime.status',
  'runtime.powerOn',
  'runtime.powerOff',
  'runtime.reset',
  'runtime.pause',
  'runtime.resume',
  'system.version'
];

/** 由主进程处理的请求名。 */
export const MAIN_REQUEST_NAMES: readonly string[] = [
  'cartridges.open',
  'cartridges.recent',
  'cartridges.openRecent',
  'machines.openBios',
  'machines.openBiosDirectory',
  'mappers.openPackage',
  'media.openFloppy',
  'media.openTape',
  'media.openTapeRecording',
  'preferences.pickDirectory',
  'system.openLogDirectory',
  'system.openHelp',
  'system.updateStatus',
  'system.checkUpdate',
  'system.installUpdate'
];

/** 全部事件名。 */
export const CORE_EVENT_NAMES: readonly string[] = [
  'cartridges.loaded',
  'debug.statusChanged',
  'debug.eventsDropped',
  'input.bindingsChanged',
  'inspector.stateChanged',
  'machines.changed',
  'mappers.changed',
  'media.changed',
  'media.printed',
  'media.printFailed',
  'media.floppySaveFailed',
  'preferences.changed',
  'runtime.stateChanged',
  'runtime.frame',
  'runtime.runFinished',
  'runtime.breakpointHit',
  'runtime.error'
];

/** 全部模块的 Schema。 */
export const CORE_SCHEMAS: readonly ModuleSchema[] = [CARTRIDGES_SCHEMA, DEBUG_SCHEMA, INPUT_SCHEMA, INSPECTOR_SCHEMA, MACHINES_SCHEMA, MAPPERS_SCHEMA, MEDIA_SCHEMA, OUTPUT_SCHEMA, PREFERENCES_SCHEMA, RUNTIME_SCHEMA, SYSTEM_SCHEMA];

/** 按模块分组的请求方法：预加载脚本按它向界面暴露具名方法。 */
export interface CoreApi {
  "cartridges": {
    eject: (params: CoreParams<'cartridges.eject'>) => Promise<CoreResult<'cartridges.eject'>>;
    info: (params: CoreParams<'cartridges.info'>) => Promise<CoreResult<'cartridges.info'>>;
  };
  "debug": {
    status: (params: CoreParams<'debug.status'>) => Promise<CoreResult<'debug.status'>>;
  };
  "input": {
    getBindings: (params: CoreParams<'input.getBindings'>) => Promise<CoreResult<'input.getBindings'>>;
    setBindings: (params: CoreParams<'input.setBindings'>) => Promise<CoreResult<'input.setBindings'>>;
    resetBindings: (params: CoreParams<'input.resetBindings'>) => Promise<CoreResult<'input.resetBindings'>>;
  };
  "inspector": {

  };
  "machines": {
    list: (params: CoreParams<'machines.list'>) => Promise<CoreResult<'machines.list'>>;
    removeBios: (params: CoreParams<'machines.removeBios'>) => Promise<CoreResult<'machines.removeBios'>>;
    boot: (params: CoreParams<'machines.boot'>) => Promise<CoreResult<'machines.boot'>>;
  };
  "mappers": {
    list: (params: CoreParams<'mappers.list'>) => Promise<CoreResult<'mappers.list'>>;
    info: (params: CoreParams<'mappers.info'>) => Promise<CoreResult<'mappers.info'>>;
    uninstall: (params: CoreParams<'mappers.uninstall'>) => Promise<CoreResult<'mappers.uninstall'>>;
    setEnabled: (params: CoreParams<'mappers.setEnabled'>) => Promise<CoreResult<'mappers.setEnabled'>>;
    reload: (params: CoreParams<'mappers.reload'>) => Promise<CoreResult<'mappers.reload'>>;
  };
  "media": {
    floppyEject: (params: CoreParams<'media.floppyEject'>) => Promise<CoreResult<'media.floppyEject'>>;
    floppySave: (params: CoreParams<'media.floppySave'>) => Promise<CoreResult<'media.floppySave'>>;
    floppyWriteProtect: (params: CoreParams<'media.floppyWriteProtect'>) => Promise<CoreResult<'media.floppyWriteProtect'>>;
    floppyStatus: (params: CoreParams<'media.floppyStatus'>) => Promise<CoreResult<'media.floppyStatus'>>;
    printerStatus: (params: CoreParams<'media.printerStatus'>) => Promise<CoreResult<'media.printerStatus'>>;
    printerFlush: (params: CoreParams<'media.printerFlush'>) => Promise<CoreResult<'media.printerFlush'>>;
    tapeEject: (params: CoreParams<'media.tapeEject'>) => Promise<CoreResult<'media.tapeEject'>>;
    tapePlay: (params: CoreParams<'media.tapePlay'>) => Promise<CoreResult<'media.tapePlay'>>;
    tapeStop: (params: CoreParams<'media.tapeStop'>) => Promise<CoreResult<'media.tapeStop'>>;
    tapeStatus: (params: CoreParams<'media.tapeStatus'>) => Promise<CoreResult<'media.tapeStatus'>>;
  };
  "output": {
    setVolume: (params: CoreParams<'output.setVolume'>) => Promise<CoreResult<'output.setVolume'>>;
  };
  "preferences": {
    list: (params: CoreParams<'preferences.list'>) => Promise<CoreResult<'preferences.list'>>;
    set: (params: CoreParams<'preferences.set'>) => Promise<CoreResult<'preferences.set'>>;
    reset: (params: CoreParams<'preferences.reset'>) => Promise<CoreResult<'preferences.reset'>>;
  };
  "runtime": {
    status: (params: CoreParams<'runtime.status'>) => Promise<CoreResult<'runtime.status'>>;
    powerOn: (params: CoreParams<'runtime.powerOn'>) => Promise<CoreResult<'runtime.powerOn'>>;
    powerOff: (params: CoreParams<'runtime.powerOff'>) => Promise<CoreResult<'runtime.powerOff'>>;
    reset: (params: CoreParams<'runtime.reset'>) => Promise<CoreResult<'runtime.reset'>>;
    pause: (params: CoreParams<'runtime.pause'>) => Promise<CoreResult<'runtime.pause'>>;
    resume: (params: CoreParams<'runtime.resume'>) => Promise<CoreResult<'runtime.resume'>>;
  };
  "system": {
    version: (params: CoreParams<'system.version'>) => Promise<CoreResult<'system.version'>>;
  };
}

/** 按模块分组的主进程请求方法：预加载脚本按它向界面暴露具名方法。 */
export interface MainApi {
  "cartridges": {
    open: (params: MainParams<'cartridges.open'>) => Promise<MainResult<'cartridges.open'>>;
    recent: (params: MainParams<'cartridges.recent'>) => Promise<MainResult<'cartridges.recent'>>;
    openRecent: (params: MainParams<'cartridges.openRecent'>) => Promise<MainResult<'cartridges.openRecent'>>;
  };
  "machines": {
    openBios: (params: MainParams<'machines.openBios'>) => Promise<MainResult<'machines.openBios'>>;
    openBiosDirectory: (params: MainParams<'machines.openBiosDirectory'>) => Promise<MainResult<'machines.openBiosDirectory'>>;
  };
  "mappers": {
    openPackage: (params: MainParams<'mappers.openPackage'>) => Promise<MainResult<'mappers.openPackage'>>;
  };
  "media": {
    openFloppy: (params: MainParams<'media.openFloppy'>) => Promise<MainResult<'media.openFloppy'>>;
    openTape: (params: MainParams<'media.openTape'>) => Promise<MainResult<'media.openTape'>>;
    openTapeRecording: (params: MainParams<'media.openTapeRecording'>) => Promise<MainResult<'media.openTapeRecording'>>;
  };
  "preferences": {
    pickDirectory: (params: MainParams<'preferences.pickDirectory'>) => Promise<MainResult<'preferences.pickDirectory'>>;
  };
  "system": {
    openLogDirectory: (params: MainParams<'system.openLogDirectory'>) => Promise<MainResult<'system.openLogDirectory'>>;
    openHelp: (params: MainParams<'system.openHelp'>) => Promise<MainResult<'system.openHelp'>>;
    updateStatus: (params: MainParams<'system.updateStatus'>) => Promise<MainResult<'system.updateStatus'>>;
    checkUpdate: (params: MainParams<'system.checkUpdate'>) => Promise<MainResult<'system.checkUpdate'>>;
    installUpdate: (params: MainParams<'system.installUpdate'>) => Promise<MainResult<'system.installUpdate'>>;
  };
}
