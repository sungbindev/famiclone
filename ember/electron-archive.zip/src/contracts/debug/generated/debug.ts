// 由 tools/schema-gen/schema-gen.mjs 根据 schema/debug.schema.json 生成，不要手改。
/* eslint-disable */


import type { ModuleSchema } from '../../../shared/schema/schema-types';

/** 一个已经通过握手的调试连接。 */
export interface DebugConnection {
  /** 连接编号，本次运行内唯一 */
  id: number;
  /** 客户端在 hello 里自报的名称 */
  client: string;
  /** 握手完成的时间，UTC，ISO 8601 */
  connectedAt: string;
}

export interface DebugHelloParams {
  /** 客户端名称，如 copilot、ember-debug-cli */
  client: string;
  /** 调试服务的令牌 */
  token: string;
  /** 客户端使用的协议版本，目前只有 1；省略时按 1 */
  protocol?: number;
}

export interface DebugHelloResult {
  /** 服务端的协议版本 */
  protocol: number;
  /** 核心版本 */
  coreVersion: string;
  /** 应用版本 */
  appVersion: string;
  /** 本连接的编号 */
  session: number;
}

export interface DebugSubscribeParams {
  /** 事件名或通配写法 */
  events: string[];
}

export interface DebugSubscribeResult {
  /** 订阅之后本连接订阅的全部事件名或通配写法 */
  events: string[];
}

export interface DebugUnsubscribeParams {
  /** 事件名或通配写法 */
  events: string[];
}

export interface DebugUnsubscribeResult {
  /** 取消之后本连接订阅的全部事件名或通配写法 */
  events: string[];
}

export type DebugStatusParams = Record<string, never>;

export interface DebugStatusResult {
  /** 是否开启（首选项里打开，或启动参数 --debug-port 指定） */
  enabled: boolean;
  /** 是否正在监听；开启但端口被占用时为 false */
  listening: boolean;
  /** 监听的端口，没有监听时为 0 */
  port: number;
  /** 开启了但没有监听时的原因；其他情况没有这一项 */
  error?: string;
  /** 当前的连接 */
  connections: DebugConnection[];
}

export interface DebugStatusChangedData {
  /** 是否开启 */
  enabled: boolean;
  /** 是否正在监听 */
  listening: boolean;
  /** 监听的端口，没有监听时为 0 */
  port: number;
  /** 当前的连接数 */
  connections: number;
}

export interface DebugEventsDroppedData {
  /** 自上一次通知以来丢弃的事件条数 */
  count: number;
}

/** 本模块的请求名。 */
export const DEBUG_REQUESTS = {
  hello: 'debug.hello',
  subscribe: 'debug.subscribe',
  unsubscribe: 'debug.unsubscribe',
  status: 'debug.status'
} as const;

/** 本模块由主进程处理的请求名。 */
export const DEBUG_MAIN_REQUESTS = {

} as const;

/** 本模块的事件名。 */
export const DEBUG_EVENTS = {
  statusChanged: 'debug.statusChanged',
  eventsDropped: 'debug.eventsDropped'
} as const;

/** 请求名到参数与结果类型的对照。 */
export interface DebugRequestMap {
  'debug.hello': { params: DebugHelloParams; result: DebugHelloResult };
  'debug.subscribe': { params: DebugSubscribeParams; result: DebugSubscribeResult };
  'debug.unsubscribe': { params: DebugUnsubscribeParams; result: DebugUnsubscribeResult };
  'debug.status': { params: DebugStatusParams; result: DebugStatusResult };
}

/** 主进程处理的请求名到参数与结果类型的对照。 */
export type DebugMainRequestMap = Record<never, never>;

/** 事件名到数据类型的对照。 */
export interface DebugEventMap {
  'debug.statusChanged': DebugStatusChangedData;
  'debug.eventsDropped': DebugEventsDroppedData;
}

/** 本模块的 Schema，供入口校验使用。 */
export const DEBUG_SCHEMA: ModuleSchema = {
  "module": "debug",
  "types": {
    "DebugConnection": {
      "type": "object",
      "description": "一个已经通过握手的调试连接。",
      "properties": {
        "id": {
          "type": "integer",
          "minimum": 1,
          "description": "连接编号，本次运行内唯一"
        },
        "client": {
          "type": "string",
          "description": "客户端在 hello 里自报的名称"
        },
        "connectedAt": {
          "type": "string",
          "description": "握手完成的时间，UTC，ISO 8601"
        }
      },
      "required": [
        "id",
        "client",
        "connectedAt"
      ]
    }
  },
  "requests": {
    "hello": {
      "description": "握手：每条连接上第一个请求必须是它，令牌不对时连接被关闭（关闭码 4001）。成功后才能调用其他请求。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "client": {
            "type": "string",
            "minLength": 1,
            "maxLength": 64,
            "description": "客户端名称，如 copilot、ember-debug-cli"
          },
          "token": {
            "type": "string",
            "minLength": 1,
            "maxLength": 128,
            "description": "调试服务的令牌"
          },
          "protocol": {
            "type": "integer",
            "minimum": 1,
            "maximum": 1,
            "description": "客户端使用的协议版本，目前只有 1；省略时按 1"
          }
        },
        "required": [
          "client",
          "token"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "protocol": {
            "type": "integer",
            "minimum": 1,
            "description": "服务端的协议版本"
          },
          "coreVersion": {
            "type": "string",
            "description": "核心版本"
          },
          "appVersion": {
            "type": "string",
            "description": "应用版本"
          },
          "session": {
            "type": "integer",
            "minimum": 1,
            "description": "本连接的编号"
          }
        },
        "required": [
          "protocol",
          "coreVersion",
          "appVersion",
          "session"
        ]
      },
      "errors": [
        "debug.unauthorized",
        "debug.unsupportedProtocol"
      ]
    },
    "subscribe": {
      "description": "订阅事件。事件名写成“模块.事件”，也可以写“模块.*”订阅一个模块的全部事件，或“*”订阅全部；已经订阅的重复订阅没有效果。高频事件默认不推送，要订阅才有。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "events": {
            "type": "array",
            "items": {
              "type": "string",
              "minLength": 1,
              "maxLength": 64
            },
            "minItems": 1,
            "maxItems": 64,
            "description": "事件名或通配写法"
          }
        },
        "required": [
          "events"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "events": {
            "type": "array",
            "items": {
              "type": "string"
            },
            "description": "订阅之后本连接订阅的全部事件名或通配写法"
          }
        },
        "required": [
          "events"
        ]
      },
      "errors": []
    },
    "unsubscribe": {
      "description": "取消订阅：写法要与订阅时一致；没有订阅过的忽略。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "events": {
            "type": "array",
            "items": {
              "type": "string",
              "minLength": 1,
              "maxLength": 64
            },
            "minItems": 1,
            "maxItems": 64,
            "description": "事件名或通配写法"
          }
        },
        "required": [
          "events"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "events": {
            "type": "array",
            "items": {
              "type": "string"
            },
            "description": "取消之后本连接订阅的全部事件名或通配写法"
          }
        },
        "required": [
          "events"
        ]
      },
      "errors": []
    },
    "status": {
      "description": "调试服务的状态：是否开启、是否在监听、端口与当前的连接。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "enabled": {
            "type": "boolean",
            "description": "是否开启（首选项里打开，或启动参数 --debug-port 指定）"
          },
          "listening": {
            "type": "boolean",
            "description": "是否正在监听；开启但端口被占用时为 false"
          },
          "port": {
            "type": "integer",
            "minimum": 0,
            "maximum": 65535,
            "description": "监听的端口，没有监听时为 0"
          },
          "error": {
            "type": "string",
            "description": "开启了但没有监听时的原因；其他情况没有这一项"
          },
          "connections": {
            "type": "array",
            "items": {
              "$ref": "#/types/DebugConnection"
            },
            "description": "当前的连接"
          }
        },
        "required": [
          "enabled",
          "listening",
          "port",
          "connections"
        ]
      },
      "errors": []
    }
  },
  "mainRequests": {},
  "events": {
    "statusChanged": {
      "description": "服务的状态变了：开始或停止监听、有连接建立或断开。",
      "data": {
        "type": "object",
        "properties": {
          "enabled": {
            "type": "boolean",
            "description": "是否开启"
          },
          "listening": {
            "type": "boolean",
            "description": "是否正在监听"
          },
          "port": {
            "type": "integer",
            "minimum": 0,
            "maximum": 65535,
            "description": "监听的端口，没有监听时为 0"
          },
          "connections": {
            "type": "integer",
            "minimum": 0,
            "description": "当前的连接数"
          }
        },
        "required": [
          "enabled",
          "listening",
          "port",
          "connections"
        ]
      }
    },
    "eventsDropped": {
      "description": "只发给订阅事件的那条连接：客户端读得太慢，事件队列已满，丢弃了若干条事件；响应不会被丢弃。",
      "data": {
        "type": "object",
        "properties": {
          "count": {
            "type": "integer",
            "minimum": 1,
            "description": "自上一次通知以来丢弃的事件条数"
          }
        },
        "required": [
          "count"
        ]
      }
    }
  }
};
