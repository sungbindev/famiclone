// 由 tools/schema-gen/schema-gen.mjs 根据 schema/input.schema.json 生成，不要手改。
/* eslint-disable */


import type { ModuleSchema } from '../../../shared/schema/schema-types';

/** 手柄的一个键绑定到键盘的一个物理键。 */
export interface PadKeyBinding {
  /** 手柄的键：turboA、turboB 是连发 A、连发 B */
  button: "a" | "b" | "select" | "start" | "up" | "down" | "left" | "right" | "turboA" | "turboB";
  /** 物理键位，取 KeyboardEvent.code，如 KeyZ、ArrowUp、Enter */
  code: string;
}

/** 手柄的一个键绑定到实体手柄的一个按钮或一个轴的一个方向。 */
export interface PadGamepadBinding {
  /** 手柄的键 */
  button: "a" | "b" | "select" | "start" | "up" | "down" | "left" | "right" | "turboA" | "turboB";
  /** 来源：button 是一个按钮，axis 是一个轴的一个方向 */
  kind: "button" | "axis";
  /** 按钮或轴的编号，同浏览器 Gamepad API 的数组下标 */
  index: number;
  /** 轴的方向：negative 是小于 -0.5，positive 是大于 0.5；只有 axis 用 */
  direction?: "negative" | "positive";
}

/** 一个玩家槽位用的实体手柄，以及它的键绑定。 */
export interface PadGamepadAssignment {
  /** 手柄的设备标识，取 Gamepad.id（含设备名） */
  id: string;
  /** 同一个设备标识连着多个手柄时，按编号从小到大排的第几个，从 0 开始 */
  occurrence: number;
  /** 手柄的键的绑定；没有写的键没有绑定，同一个键只能写一次 */
  bindings: PadGamepadBinding[];
}

/** 一个玩家槽位：键盘的绑定，以及可选的一个实体手柄。 */
export interface PadSlot {
  /** 键盘的绑定；没有写的键没有绑定，同一个键只能写一次 */
  keys: PadKeyBinding[];
  gamepad?: PadGamepadAssignment;
}

export type InputGetBindingsParams = Record<string, never>;

export interface InputGetBindingsResult {
  /** 玩家槽位，第 1 项是手柄口 1 */
  slots: PadSlot[];
}

export interface InputSetBindingsParams {
  /** 玩家槽位，第 1 项是手柄口 1 */
  slots: PadSlot[];
}

export interface InputSetBindingsResult {
  /** 保存之后的玩家槽位 */
  slots: PadSlot[];
}

export type InputResetBindingsParams = Record<string, never>;

export interface InputResetBindingsResult {
  /** 恢复之后的玩家槽位 */
  slots: PadSlot[];
}

export interface InputKeyParams {
  /** 物理键位，取 KeyboardEvent.code，如 KeyW、Space、Numpad1、Enter */
  code: string;
  /** true 按下，false 松开 */
  down: boolean;
}

export type InputKeyResult = Record<string, never>;

export interface InputMouseParams {
  /** 事件种类 */
  kind: "move" | "down" | "up" | "wheel" | "leave";
  /** 指针在标准帧上的横坐标，可以超出画面范围 */
  x?: number;
  /** 指针在标准帧上的纵坐标，可以超出画面范围 */
  y?: number;
  /** 相对上一次事件的横向位移 */
  dx?: number;
  /** 相对上一次事件的纵向位移 */
  dy?: number;
  /** 当前按住的按键位：1 左键、2 右键、4 中键 */
  buttons?: number;
  /** 滚轮的滚动量，向下为正，只有 wheel 事件用 */
  wheel?: number;
}

export type InputMouseResult = Record<string, never>;

export interface InputGamepadParams {
  /** 手柄编号，同浏览器 Gamepad API 的 index */
  index: number;
  /** 手柄的设备标识，取 Gamepad.id；省略时按空处理 */
  id?: string;
  /** 是否连着 */
  connected: boolean;
  /** 各按键是否按下，顺序同浏览器的标准映射 */
  buttons?: boolean[];
  /** 各轴的值，范围 -1 到 1，顺序同浏览器的标准映射 */
  axes?: number[];
}

export type InputGamepadResult = Record<string, never>;

export interface InputPadParams {
  /** 手柄口编号，从 0 开始 */
  port: number;
  /** 按键掩码，1 表示按下 */
  buttons: number;
}

export type InputPadResult = Record<string, never>;

export type InputReleaseAllParams = Record<string, never>;

export type InputReleaseAllResult = Record<string, never>;

export interface InputBindingsChangedData {
  /** 新的玩家槽位 */
  slots: PadSlot[];
}

/** 本模块的请求名。 */
export const INPUT_REQUESTS = {
  getBindings: 'input.getBindings',
  setBindings: 'input.setBindings',
  resetBindings: 'input.resetBindings',
  key: 'input.key',
  mouse: 'input.mouse',
  gamepad: 'input.gamepad',
  pad: 'input.pad',
  releaseAll: 'input.releaseAll'
} as const;

/** 本模块由主进程处理的请求名。 */
export const INPUT_MAIN_REQUESTS = {

} as const;

/** 本模块的事件名。 */
export const INPUT_EVENTS = {
  bindingsChanged: 'input.bindingsChanged'
} as const;

/** 请求名到参数与结果类型的对照。 */
export interface InputRequestMap {
  'input.getBindings': { params: InputGetBindingsParams; result: InputGetBindingsResult };
  'input.setBindings': { params: InputSetBindingsParams; result: InputSetBindingsResult };
  'input.resetBindings': { params: InputResetBindingsParams; result: InputResetBindingsResult };
  'input.key': { params: InputKeyParams; result: InputKeyResult };
  'input.mouse': { params: InputMouseParams; result: InputMouseResult };
  'input.gamepad': { params: InputGamepadParams; result: InputGamepadResult };
  'input.pad': { params: InputPadParams; result: InputPadResult };
  'input.releaseAll': { params: InputReleaseAllParams; result: InputReleaseAllResult };
}

/** 主进程处理的请求名到参数与结果类型的对照。 */
export type InputMainRequestMap = Record<never, never>;

/** 事件名到数据类型的对照。 */
export interface InputEventMap {
  'input.bindingsChanged': InputBindingsChangedData;
}

/** 本模块的 Schema，供入口校验使用。 */
export const INPUT_SCHEMA: ModuleSchema = {
  "module": "input",
  "types": {
    "PadKeyBinding": {
      "type": "object",
      "description": "手柄的一个键绑定到键盘的一个物理键。",
      "properties": {
        "button": {
          "type": "string",
          "enum": [
            "a",
            "b",
            "select",
            "start",
            "up",
            "down",
            "left",
            "right",
            "turboA",
            "turboB"
          ],
          "description": "手柄的键：turboA、turboB 是连发 A、连发 B"
        },
        "code": {
          "type": "string",
          "minLength": 1,
          "maxLength": 32,
          "description": "物理键位，取 KeyboardEvent.code，如 KeyZ、ArrowUp、Enter"
        }
      },
      "required": [
        "button",
        "code"
      ]
    },
    "PadGamepadBinding": {
      "type": "object",
      "description": "手柄的一个键绑定到实体手柄的一个按钮或一个轴的一个方向。",
      "properties": {
        "button": {
          "type": "string",
          "enum": [
            "a",
            "b",
            "select",
            "start",
            "up",
            "down",
            "left",
            "right",
            "turboA",
            "turboB"
          ],
          "description": "手柄的键"
        },
        "kind": {
          "type": "string",
          "enum": [
            "button",
            "axis"
          ],
          "description": "来源：button 是一个按钮，axis 是一个轴的一个方向"
        },
        "index": {
          "type": "integer",
          "minimum": 0,
          "maximum": 31,
          "description": "按钮或轴的编号，同浏览器 Gamepad API 的数组下标"
        },
        "direction": {
          "type": "string",
          "enum": [
            "negative",
            "positive"
          ],
          "description": "轴的方向：negative 是小于 -0.5，positive 是大于 0.5；只有 axis 用"
        }
      },
      "required": [
        "button",
        "kind",
        "index"
      ]
    },
    "PadGamepadAssignment": {
      "type": "object",
      "description": "一个玩家槽位用的实体手柄，以及它的键绑定。",
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1,
          "maxLength": 256,
          "description": "手柄的设备标识，取 Gamepad.id（含设备名）"
        },
        "occurrence": {
          "type": "integer",
          "minimum": 0,
          "maximum": 15,
          "description": "同一个设备标识连着多个手柄时，按编号从小到大排的第几个，从 0 开始"
        },
        "bindings": {
          "type": "array",
          "items": {
            "$ref": "#/types/PadGamepadBinding"
          },
          "maxItems": 10,
          "description": "手柄的键的绑定；没有写的键没有绑定，同一个键只能写一次"
        }
      },
      "required": [
        "id",
        "occurrence",
        "bindings"
      ]
    },
    "PadSlot": {
      "type": "object",
      "description": "一个玩家槽位：键盘的绑定，以及可选的一个实体手柄。",
      "properties": {
        "keys": {
          "type": "array",
          "items": {
            "$ref": "#/types/PadKeyBinding"
          },
          "maxItems": 10,
          "description": "键盘的绑定；没有写的键没有绑定，同一个键只能写一次"
        },
        "gamepad": {
          "$ref": "#/types/PadGamepadAssignment"
        }
      },
      "required": [
        "keys"
      ]
    }
  },
  "requests": {
    "getBindings": {
      "description": "读取手柄绑定：两个玩家槽位（对应手柄口 1、2）。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "slots": {
            "type": "array",
            "items": {
              "$ref": "#/types/PadSlot"
            },
            "minItems": 2,
            "maxItems": 2,
            "description": "玩家槽位，第 1 项是手柄口 1"
          }
        },
        "required": [
          "slots"
        ]
      },
      "errors": []
    },
    "setBindings": {
      "description": "替换全部手柄绑定：核心校验后保存到文件，并发出 input.bindingsChanged；内容没有变化时不发事件。",
      "params": {
        "type": "object",
        "properties": {
          "slots": {
            "type": "array",
            "items": {
              "$ref": "#/types/PadSlot"
            },
            "minItems": 2,
            "maxItems": 2,
            "description": "玩家槽位，第 1 项是手柄口 1"
          }
        },
        "required": [
          "slots"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "slots": {
            "type": "array",
            "items": {
              "$ref": "#/types/PadSlot"
            },
            "minItems": 2,
            "maxItems": 2,
            "description": "保存之后的玩家槽位"
          }
        },
        "required": [
          "slots"
        ]
      },
      "errors": [
        "input.invalidBindings"
      ]
    },
    "resetBindings": {
      "description": "把手柄绑定恢复为出厂默认；内容没有变化时不发事件。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "slots": {
            "type": "array",
            "items": {
              "$ref": "#/types/PadSlot"
            },
            "minItems": 2,
            "maxItems": 2,
            "description": "恢复之后的玩家槽位"
          }
        },
        "required": [
          "slots"
        ]
      },
      "errors": []
    },
    "key": {
      "description": "按下或松开一个物理键：键盘属于机器时交给机器，否则按手柄绑定变成手柄口的按键；没有开机时被丢弃。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "code": {
            "type": "string",
            "minLength": 1,
            "maxLength": 32,
            "description": "物理键位，取 KeyboardEvent.code，如 KeyW、Space、Numpad1、Enter"
          },
          "down": {
            "type": "boolean",
            "description": "true 按下，false 松开"
          }
        },
        "required": [
          "code",
          "down"
        ]
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": []
    },
    "mouse": {
      "description": "鼠标事件，交给机器；坐标单位是标准帧（256x240）的像素，省略的数值按 0 处理。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "kind": {
            "type": "string",
            "enum": [
              "move",
              "down",
              "up",
              "wheel",
              "leave"
            ],
            "description": "事件种类"
          },
          "x": {
            "type": "number",
            "description": "指针在标准帧上的横坐标，可以超出画面范围"
          },
          "y": {
            "type": "number",
            "description": "指针在标准帧上的纵坐标，可以超出画面范围"
          },
          "dx": {
            "type": "number",
            "description": "相对上一次事件的横向位移"
          },
          "dy": {
            "type": "number",
            "description": "相对上一次事件的纵向位移"
          },
          "buttons": {
            "type": "integer",
            "minimum": 0,
            "maximum": 7,
            "description": "当前按住的按键位：1 左键、2 右键、4 中键"
          },
          "wheel": {
            "type": "number",
            "description": "滚轮的滚动量，向下为正，只有 wheel 事件用"
          }
        },
        "required": [
          "kind"
        ]
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": []
    },
    "gamepad": {
      "description": "游戏手柄一个手柄的当前全部状态，按手柄绑定变成手柄口的按键；拔掉时 connected 为 false，按键与轴省略。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "index": {
            "type": "integer",
            "minimum": 0,
            "maximum": 7,
            "description": "手柄编号，同浏览器 Gamepad API 的 index"
          },
          "id": {
            "type": "string",
            "maxLength": 256,
            "description": "手柄的设备标识，取 Gamepad.id；省略时按空处理"
          },
          "connected": {
            "type": "boolean",
            "description": "是否连着"
          },
          "buttons": {
            "type": "array",
            "items": {
              "type": "boolean"
            },
            "maxItems": 32,
            "description": "各按键是否按下，顺序同浏览器的标准映射"
          },
          "axes": {
            "type": "array",
            "items": {
              "type": "number"
            },
            "maxItems": 16,
            "description": "各轴的值，范围 -1 到 1，顺序同浏览器的标准映射"
          }
        },
        "required": [
          "index",
          "connected"
        ]
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": []
    },
    "pad": {
      "description": "直接设置主机某个手柄口上标准手柄的按键，不经 mapper 脚本；位：1 A、2 B、4 选择、8 开始、16 上、32 下、64 左、128 右。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "port": {
            "type": "integer",
            "minimum": 0,
            "maximum": 7,
            "description": "手柄口编号，从 0 开始"
          },
          "buttons": {
            "type": "integer",
            "minimum": 0,
            "maximum": 255,
            "description": "按键掩码，1 表示按下"
          }
        },
        "required": [
          "port",
          "buttons"
        ]
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": [
        "input.invalidPort"
      ]
    },
    "releaseAll": {
      "description": "松开经 key 按下的全部键、把经 pad 设置过的手柄口清零、并让经 gamepad 注入的手柄断开。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": []
    }
  },
  "mainRequests": {},
  "events": {
    "bindingsChanged": {
      "description": "手柄绑定变了（界面修改、恢复默认都会发出）。",
      "data": {
        "type": "object",
        "properties": {
          "slots": {
            "type": "array",
            "items": {
              "$ref": "#/types/PadSlot"
            },
            "minItems": 2,
            "maxItems": 2,
            "description": "新的玩家槽位"
          }
        },
        "required": [
          "slots"
        ]
      }
    }
  }
};
