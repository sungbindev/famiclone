// 由 tools/schema-gen/schema-gen.mjs 根据 schema/inspector.schema.json 生成，不要手改。
/* eslint-disable */


import type { ModuleSchema } from '../../../shared/schema/schema-types';

/** 一个内存空间。 */
export interface MemorySpaceInfo {
  /** 空间标识：cpu、ppu（总线视角，读不产生副作用）；board.ram 等主板上的存储；chip.oam、chip.palette 等芯片内的存储；cart.<存储区标识> 卡带上的存储区 */
  id: string;
  /** 说明 */
  description: string;
  /** 大小（字节），地址从 0 到大小减 1 */
  size: number;
  /** 能否写入；卡带的 ROM 存储区不能写 */
  writable: boolean;
}

/** 一个总线地址对应的东西。 */
export interface AddressInfo {
  /** 种类：ram 与 rom 是存储区里的字节；register 是芯片、设备或 mapper 脚本的寄存器；none 没有设备响应（读到总线上最近的值） */
  kind: "ram" | "rom" | "register" | "none";
  /** 所在存储区的空间标识（如 board.ram、cart.prg），或寄存器所属的芯片（如 chip.ppu、cart.mapper）；没有时省略 */
  region?: string;
  /** 在存储区里的偏移，或在寄存器组里的序号；没有时省略 */
  offset?: number;
  /** 说明 */
  description: string;
}

/** 一项状态。 */
export interface StateField {
  /** 状态项名称 */
  name: string;
  /** 取值；标志位是 0 或 1 */
  value: number;
  /** 说明（读出时有，写入时可省略） */
  description?: string;
}

/** 一个断点。 */
export interface Breakpoint {
  /** 断点编号 */
  id: number;
  /** 种类：execute CPU 要执行这个地址的指令之前停下；read、write 总线读写这个范围里的地址，那条指令执行完后停下 */
  kind: "execute" | "read" | "write";
  /** 地址范围的第一个地址 */
  address: number;
  /** 地址范围的最后一个地址（含）；单个地址时与 address 相同 */
  endAddress: number;
  /** 已经命中的次数 */
  hits: number;
}

/** 一个字节的取值条件：CPU 总线上这个地址的字节等于这个值。 */
export interface ByteCondition {
  /** 地址 */
  address: number;
  /** 取值 */
  value: number;
}

/** 一条反汇编的指令。 */
export interface DisassembledInstruction {
  /** 指令的地址 */
  address: number;
  /** 指令字节，十六进制，空格隔开，如 A9 42 */
  bytes: string;
  /** 助记符与操作数，带有效地址与取值的注释，如 LDA $0180 = 33；写法同 nestest 日志，芯片寄存器类地址的取值显示 00 */
  text: string;
  /** 是不是非官方指令 */
  unofficial: boolean;
}

/** 一段内存，CPU 总线上的地址。 */
export interface MemoryRangeSpec {
  /** 起始地址 */
  address: number;
  /** 字节数 */
  length: number;
}

/** 一个监视中的状态项。 */
export interface WatchedValue {
  /** 状态路径，如 cpu.pc、ppu.scanline、mapper.prgBank */
  path: string;
  /** 当前取值 */
  value: number;
}

/** 一个模块的状态。 */
export interface ModuleState {
  /** 模块标识：cpu、ppu；卡带的脚本状态是 mapper */
  module: string;
  /** 状态是否可以用 setState 修改（cpu 的 cycles 除外） */
  writable: boolean;
  /** 状态项 */
  fields: StateField[];
}

export type InspectorListSpacesParams = Record<string, never>;

export interface InspectorListSpacesResult {
  /** 内存空间 */
  spaces: MemorySpaceInfo[];
}

export interface InspectorReadMemoryParams {
  /** 空间标识，见 listSpaces */
  space: string;
  /** 起始地址 */
  address: number;
  /** 要读的字节数 */
  length: number;
}

export interface InspectorReadMemoryResult {
  /** 空间标识 */
  space: string;
  /** 起始地址 */
  address: number;
  /** 字节数 */
  length: number;
  /** 读到的字节（二进制，以二进制帧送达） */
  data?: unknown;
}

export interface InspectorWriteMemoryParams {
  /** 空间标识，见 listSpaces */
  space: string;
  /** 起始地址 */
  address: number;
  /** 要写入的字节，每项 0 到 255 */
  bytes: number[];
}

export interface InspectorWriteMemoryResult {
  /** 空间标识 */
  space: string;
  /** 起始地址 */
  address: number;
  /** 写入的字节数 */
  written: number;
}

export interface InspectorResolveParams {
  /** 总线：cpu 或 ppu */
  space: "cpu" | "ppu";
  /** 总线地址 */
  address: number;
}

export interface InspectorResolveResult {
  /** 解析结果 */
  target: AddressInfo;
}

export interface InspectorGetStateParams {
  /** 模块标识；省略时返回全部 */
  module?: string;
}

export interface InspectorGetStateResult {
  /** 各模块的状态 */
  states: ModuleState[];
}

export interface InspectorSnapshotParams {
  /** 只取这个模块的状态；省略时取全部 */
  module?: string;
}

export interface InspectorSnapshotResult {
  /** 自上电以来的 CPU 周期数 */
  cycles: number;
  /** 各模块的状态 */
  states: ModuleState[];
  /** 全部断点 */
  breakpoints: Breakpoint[];
  /** 全部监视项与当前取值 */
  watches: WatchedValue[];
}

export interface InspectorWatchParams {
  /** 状态路径 */
  path: string;
}

export interface InspectorWatchResult {
  /** 监视项与当前取值 */
  watch: WatchedValue;
}

export interface InspectorUnwatchParams {
  /** 状态路径 */
  path: string;
}

export type InspectorUnwatchResult = Record<string, never>;

export interface InspectorDisassembleParams {
  /** 起始地址 */
  address: number;
  /** 指令条数，默认 16 */
  count?: number;
}

export interface InspectorDisassembleResult {
  /** 反汇编的指令 */
  instructions: DisassembledInstruction[];
}

export type InspectorCdlStartParams = Record<string, never>;

export interface InspectorCdlStartResult {
  /** PRG-ROM 的字节数，也是标记的字节数 */
  size: number;
}

export type InspectorCdlStopParams = Record<string, never>;

export interface InspectorCdlStopResult {
  /** PRG-ROM 的字节数 */
  size: number;
  /** 标了 Code 的字节数 */
  codeBytes: number;
  /** 标了 Data 的字节数 */
  dataBytes: number;
}

export interface InspectorCdlSaveParams {
  /** 文件名，只能含字母、数字、点、下划线、短横线与空格，不含目录；省略时用 prg.cdl */
  file?: string;
}

export interface InspectorCdlSaveResult {
  /** 保存的文件的完整路径 */
  file: string;
  /** PRG-ROM 的字节数，也是文件的字节数 */
  size: number;
  /** 标了 Code 的字节数 */
  codeBytes: number;
  /** 标了 Data 的字节数 */
  dataBytes: number;
}

export interface InspectorTraceStartParams {
  /** 跟踪的种类 */
  kind: "instruction" | "io" | "irq";
  /** 文件名，只能含字母、数字、点、下划线、短横线与空格，不含目录；省略时按种类与编号生成（trace-编号.txt、calllog-编号.txt）。文件写在调试输出目录 */
  file?: string;
  /** 最多记录的行数，满了就不再记录，默认 100000 */
  maxLines?: number;
  /** 只对 instruction 有效：每个地址只记第一次，默认 false */
  unique?: boolean;
}

export interface InspectorTraceStartResult {
  /** 记录编号 */
  id: number;
}

export interface InspectorTraceStopParams {
  /** traceStart 返回的记录编号 */
  id: number;
}

export interface InspectorTraceStopResult {
  /** 保存的文件的完整路径 */
  file: string;
  /** 写入的行数 */
  lines: number;
  /** 是否因为行数满了而少记了 */
  truncated: boolean;
}

export interface InspectorCallLogStartParams {
  /** 要记录的指令地址 */
  address: number;
  /** 每次记录栈顶的字节数，默认 0 */
  stackBytes?: number;
  /** 每次记录的内存段，最多 4 段 */
  ranges?: MemoryRangeSpec[];
  /** 跳过条件，最多 4 项：执行到这条指令时，任何一项成立（这个地址上的字节等于这个值）就不记录这一次，用来滤掉不关心的调用 */
  skip?: ByteCondition[];
  /** 文件名，只能含字母、数字、点、下划线、短横线与空格，不含目录；省略时按种类与编号生成（trace-编号.txt、calllog-编号.txt）。文件写在调试输出目录 */
  file?: string;
  /** 最多记录的行数，满了就不再记录，默认 100000 */
  maxLines?: number;
}

export interface InspectorCallLogStartResult {
  /** 记录编号 */
  id: number;
}

export interface InspectorCallLogStopParams {
  /** callLogStart 返回的记录编号 */
  id: number;
}

export interface InspectorCallLogStopResult {
  /** 保存的文件的完整路径 */
  file: string;
  /** 写入的行数 */
  lines: number;
  /** 是否因为行数满了而少记了 */
  truncated: boolean;
}

export interface InspectorAddBreakpointParams {
  /** 种类 */
  kind: "execute" | "read" | "write";
  /** 地址，或地址范围的第一个地址 */
  address: number;
  /** 地址范围的最后一个地址（含），省略时只有 address 一个地址 */
  endAddress?: number;
}

export interface InspectorAddBreakpointResult {
  /** 添加的断点 */
  breakpoint: Breakpoint;
}

export type InspectorListBreakpointsParams = Record<string, never>;

export interface InspectorListBreakpointsResult {
  /** 断点 */
  breakpoints: Breakpoint[];
}

export interface InspectorRemoveBreakpointParams {
  /** 断点编号 */
  id: number;
}

export type InspectorRemoveBreakpointResult = Record<string, never>;

export type InspectorClearBreakpointsParams = Record<string, never>;

export interface InspectorClearBreakpointsResult {
  /** 删除的个数 */
  removed: number;
}

export interface InspectorSetStateParams {
  /** 模块标识 */
  module: string;
  /** 要修改的状态项 */
  fields: StateField[];
}

export interface InspectorSetStateResult {
  /** 修改之后的状态 */
  state: ModuleState;
}

export interface InspectorStateChangedData {
  /** 状态路径 */
  path: string;
  /** 上一次检查时的取值 */
  oldValue: number;
  /** 现在的取值 */
  newValue: number;
  /** 检查时的 CPU 周期数 */
  cycles: number;
}

/** 本模块的请求名。 */
export const INSPECTOR_REQUESTS = {
  listSpaces: 'inspector.listSpaces',
  readMemory: 'inspector.readMemory',
  writeMemory: 'inspector.writeMemory',
  resolve: 'inspector.resolve',
  getState: 'inspector.getState',
  snapshot: 'inspector.snapshot',
  watch: 'inspector.watch',
  unwatch: 'inspector.unwatch',
  disassemble: 'inspector.disassemble',
  cdlStart: 'inspector.cdlStart',
  cdlStop: 'inspector.cdlStop',
  cdlSave: 'inspector.cdlSave',
  traceStart: 'inspector.traceStart',
  traceStop: 'inspector.traceStop',
  callLogStart: 'inspector.callLogStart',
  callLogStop: 'inspector.callLogStop',
  addBreakpoint: 'inspector.addBreakpoint',
  listBreakpoints: 'inspector.listBreakpoints',
  removeBreakpoint: 'inspector.removeBreakpoint',
  clearBreakpoints: 'inspector.clearBreakpoints',
  setState: 'inspector.setState'
} as const;

/** 本模块由主进程处理的请求名。 */
export const INSPECTOR_MAIN_REQUESTS = {

} as const;

/** 本模块的事件名。 */
export const INSPECTOR_EVENTS = {
  stateChanged: 'inspector.stateChanged'
} as const;

/** 请求名到参数与结果类型的对照。 */
export interface InspectorRequestMap {
  'inspector.listSpaces': { params: InspectorListSpacesParams; result: InspectorListSpacesResult };
  'inspector.readMemory': { params: InspectorReadMemoryParams; result: InspectorReadMemoryResult };
  'inspector.writeMemory': { params: InspectorWriteMemoryParams; result: InspectorWriteMemoryResult };
  'inspector.resolve': { params: InspectorResolveParams; result: InspectorResolveResult };
  'inspector.getState': { params: InspectorGetStateParams; result: InspectorGetStateResult };
  'inspector.snapshot': { params: InspectorSnapshotParams; result: InspectorSnapshotResult };
  'inspector.watch': { params: InspectorWatchParams; result: InspectorWatchResult };
  'inspector.unwatch': { params: InspectorUnwatchParams; result: InspectorUnwatchResult };
  'inspector.disassemble': { params: InspectorDisassembleParams; result: InspectorDisassembleResult };
  'inspector.cdlStart': { params: InspectorCdlStartParams; result: InspectorCdlStartResult };
  'inspector.cdlStop': { params: InspectorCdlStopParams; result: InspectorCdlStopResult };
  'inspector.cdlSave': { params: InspectorCdlSaveParams; result: InspectorCdlSaveResult };
  'inspector.traceStart': { params: InspectorTraceStartParams; result: InspectorTraceStartResult };
  'inspector.traceStop': { params: InspectorTraceStopParams; result: InspectorTraceStopResult };
  'inspector.callLogStart': { params: InspectorCallLogStartParams; result: InspectorCallLogStartResult };
  'inspector.callLogStop': { params: InspectorCallLogStopParams; result: InspectorCallLogStopResult };
  'inspector.addBreakpoint': { params: InspectorAddBreakpointParams; result: InspectorAddBreakpointResult };
  'inspector.listBreakpoints': { params: InspectorListBreakpointsParams; result: InspectorListBreakpointsResult };
  'inspector.removeBreakpoint': { params: InspectorRemoveBreakpointParams; result: InspectorRemoveBreakpointResult };
  'inspector.clearBreakpoints': { params: InspectorClearBreakpointsParams; result: InspectorClearBreakpointsResult };
  'inspector.setState': { params: InspectorSetStateParams; result: InspectorSetStateResult };
}

/** 主进程处理的请求名到参数与结果类型的对照。 */
export type InspectorMainRequestMap = Record<never, never>;

/** 事件名到数据类型的对照。 */
export interface InspectorEventMap {
  'inspector.stateChanged': InspectorStateChangedData;
}

/** 本模块的 Schema，供入口校验使用。 */
export const INSPECTOR_SCHEMA: ModuleSchema = {
  "module": "inspector",
  "types": {
    "MemorySpaceInfo": {
      "type": "object",
      "description": "一个内存空间。",
      "properties": {
        "id": {
          "type": "string",
          "description": "空间标识：cpu、ppu（总线视角，读不产生副作用）；board.ram 等主板上的存储；chip.oam、chip.palette 等芯片内的存储；cart.<存储区标识> 卡带上的存储区"
        },
        "description": {
          "type": "string",
          "description": "说明"
        },
        "size": {
          "type": "integer",
          "minimum": 1,
          "description": "大小（字节），地址从 0 到大小减 1"
        },
        "writable": {
          "type": "boolean",
          "description": "能否写入；卡带的 ROM 存储区不能写"
        }
      },
      "required": [
        "id",
        "description",
        "size",
        "writable"
      ]
    },
    "AddressInfo": {
      "type": "object",
      "description": "一个总线地址对应的东西。",
      "properties": {
        "kind": {
          "type": "string",
          "enum": [
            "ram",
            "rom",
            "register",
            "none"
          ],
          "description": "种类：ram 与 rom 是存储区里的字节；register 是芯片、设备或 mapper 脚本的寄存器；none 没有设备响应（读到总线上最近的值）"
        },
        "region": {
          "type": "string",
          "description": "所在存储区的空间标识（如 board.ram、cart.prg），或寄存器所属的芯片（如 chip.ppu、cart.mapper）；没有时省略"
        },
        "offset": {
          "type": "integer",
          "minimum": 0,
          "description": "在存储区里的偏移，或在寄存器组里的序号；没有时省略"
        },
        "description": {
          "type": "string",
          "description": "说明"
        }
      },
      "required": [
        "kind",
        "description"
      ]
    },
    "StateField": {
      "type": "object",
      "description": "一项状态。",
      "properties": {
        "name": {
          "type": "string",
          "minLength": 1,
          "maxLength": 64,
          "description": "状态项名称"
        },
        "value": {
          "type": "integer",
          "description": "取值；标志位是 0 或 1"
        },
        "description": {
          "type": "string",
          "description": "说明（读出时有，写入时可省略）"
        }
      },
      "required": [
        "name",
        "value"
      ]
    },
    "Breakpoint": {
      "type": "object",
      "description": "一个断点。",
      "properties": {
        "id": {
          "type": "integer",
          "minimum": 1,
          "description": "断点编号"
        },
        "kind": {
          "type": "string",
          "enum": [
            "execute",
            "read",
            "write"
          ],
          "description": "种类：execute CPU 要执行这个地址的指令之前停下；read、write 总线读写这个范围里的地址，那条指令执行完后停下"
        },
        "address": {
          "type": "integer",
          "minimum": 0,
          "maximum": 65535,
          "description": "地址范围的第一个地址"
        },
        "endAddress": {
          "type": "integer",
          "minimum": 0,
          "maximum": 65535,
          "description": "地址范围的最后一个地址（含）；单个地址时与 address 相同"
        },
        "hits": {
          "type": "integer",
          "minimum": 0,
          "description": "已经命中的次数"
        }
      },
      "required": [
        "id",
        "kind",
        "address",
        "endAddress",
        "hits"
      ]
    },
    "ByteCondition": {
      "type": "object",
      "description": "一个字节的取值条件：CPU 总线上这个地址的字节等于这个值。",
      "properties": {
        "address": {
          "type": "integer",
          "minimum": 0,
          "maximum": 65535,
          "description": "地址"
        },
        "value": {
          "type": "integer",
          "minimum": 0,
          "maximum": 255,
          "description": "取值"
        }
      },
      "required": [
        "address",
        "value"
      ]
    },
    "DisassembledInstruction": {
      "type": "object",
      "description": "一条反汇编的指令。",
      "properties": {
        "address": {
          "type": "integer",
          "minimum": 0,
          "maximum": 65535,
          "description": "指令的地址"
        },
        "bytes": {
          "type": "string",
          "description": "指令字节，十六进制，空格隔开，如 A9 42"
        },
        "text": {
          "type": "string",
          "description": "助记符与操作数，带有效地址与取值的注释，如 LDA $0180 = 33；写法同 nestest 日志，芯片寄存器类地址的取值显示 00"
        },
        "unofficial": {
          "type": "boolean",
          "description": "是不是非官方指令"
        }
      },
      "required": [
        "address",
        "bytes",
        "text",
        "unofficial"
      ]
    },
    "MemoryRangeSpec": {
      "type": "object",
      "description": "一段内存，CPU 总线上的地址。",
      "properties": {
        "address": {
          "type": "integer",
          "minimum": 0,
          "maximum": 65535,
          "description": "起始地址"
        },
        "length": {
          "type": "integer",
          "minimum": 1,
          "maximum": 256,
          "description": "字节数"
        }
      },
      "required": [
        "address",
        "length"
      ]
    },
    "WatchedValue": {
      "type": "object",
      "description": "一个监视中的状态项。",
      "properties": {
        "path": {
          "type": "string",
          "description": "状态路径，如 cpu.pc、ppu.scanline、mapper.prgBank"
        },
        "value": {
          "type": "integer",
          "description": "当前取值"
        }
      },
      "required": [
        "path",
        "value"
      ]
    },
    "ModuleState": {
      "type": "object",
      "description": "一个模块的状态。",
      "properties": {
        "module": {
          "type": "string",
          "description": "模块标识：cpu、ppu；卡带的脚本状态是 mapper"
        },
        "writable": {
          "type": "boolean",
          "description": "状态是否可以用 setState 修改（cpu 的 cycles 除外）"
        },
        "fields": {
          "type": "array",
          "items": {
            "$ref": "#/types/StateField"
          },
          "description": "状态项"
        }
      },
      "required": [
        "module",
        "writable",
        "fields"
      ]
    }
  },
  "requests": {
    "listSpaces": {
      "description": "列出全部内存空间：总线视角的 cpu 与 ppu，主板与芯片里的存储，以及卡带上的存储区（cart.<存储区标识>）。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "spaces": {
            "type": "array",
            "items": {
              "$ref": "#/types/MemorySpaceInfo"
            },
            "description": "内存空间"
          }
        },
        "required": [
          "spaces"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported"
      ]
    },
    "readMemory": {
      "description": "读一段内存，不改变主机的任何状态：cpu 与 ppu 空间里寄存器类地址读出 0（不读寄存器，所以不会清标志），卡带脚本的寄存器也不会被回调。数据以二进制帧返回（结果里的 data，见 docs/04-调试服务.md 第 2.3 节）。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "space": {
            "type": "string",
            "minLength": 1,
            "maxLength": 64,
            "description": "空间标识，见 listSpaces"
          },
          "address": {
            "type": "integer",
            "minimum": 0,
            "maximum": 4294967295,
            "description": "起始地址"
          },
          "length": {
            "type": "integer",
            "minimum": 1,
            "maximum": 1048576,
            "description": "要读的字节数"
          }
        },
        "required": [
          "space",
          "address",
          "length"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "space": {
            "type": "string",
            "description": "空间标识"
          },
          "address": {
            "type": "integer",
            "minimum": 0,
            "description": "起始地址"
          },
          "length": {
            "type": "integer",
            "minimum": 1,
            "description": "字节数"
          },
          "data": {
            "description": "读到的字节（二进制，以二进制帧送达）"
          }
        },
        "required": [
          "space",
          "address",
          "length"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.unknownSpace",
        "inspector.outOfRange"
      ]
    },
    "writeMemory": {
      "description": "写一段内存。cpu 与 ppu 空间的写经真实的总线，与 CPU 写一样有副作用（写寄存器会触发相应的行为）；卡带的 ROM 存储区不能写。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "space": {
            "type": "string",
            "minLength": 1,
            "maxLength": 64,
            "description": "空间标识，见 listSpaces"
          },
          "address": {
            "type": "integer",
            "minimum": 0,
            "maximum": 4294967295,
            "description": "起始地址"
          },
          "bytes": {
            "type": "array",
            "items": {
              "type": "integer",
              "minimum": 0,
              "maximum": 255
            },
            "minItems": 1,
            "maxItems": 65536,
            "description": "要写入的字节，每项 0 到 255"
          }
        },
        "required": [
          "space",
          "address",
          "bytes"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "space": {
            "type": "string",
            "description": "空间标识"
          },
          "address": {
            "type": "integer",
            "minimum": 0,
            "description": "起始地址"
          },
          "written": {
            "type": "integer",
            "minimum": 0,
            "description": "写入的字节数"
          }
        },
        "required": [
          "space",
          "address",
          "written"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.unknownSpace",
        "inspector.outOfRange",
        "inspector.readOnly"
      ]
    },
    "resolve": {
      "description": "解析一个总线地址：它落在哪块存储区的哪个偏移，或哪个寄存器；卡带的地址按当前的窗口映射（分页）解析，不回调脚本。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "space": {
            "type": "string",
            "enum": [
              "cpu",
              "ppu"
            ],
            "description": "总线：cpu 或 ppu"
          },
          "address": {
            "type": "integer",
            "minimum": 0,
            "maximum": 65535,
            "description": "总线地址"
          }
        },
        "required": [
          "space",
          "address"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "target": {
            "$ref": "#/types/AddressInfo",
            "description": "解析结果"
          }
        },
        "required": [
          "target"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.unknownSpace",
        "inspector.outOfRange"
      ]
    },
    "getState": {
      "description": "读状态：cpu（寄存器与周期数）、ppu（扫描线、点、帧数、滚动寄存器、标志）与卡带的脚本状态（mapper）。省略 module 时返回全部模块。读取在帧边界或暂停时进行，是一致的快照。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "module": {
            "type": "string",
            "minLength": 1,
            "maxLength": 64,
            "description": "模块标识；省略时返回全部"
          }
        },
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "states": {
            "type": "array",
            "items": {
              "$ref": "#/types/ModuleState"
            },
            "description": "各模块的状态"
          }
        },
        "required": [
          "states"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.invalidState"
      ]
    },
    "snapshot": {
      "description": "取得完整快照：各模块的状态、断点与监视项，以及此刻的 CPU 周期数，都在同一个时刻读出，是一致的。内存不在快照里，用 readMemory 读。省略 module 时包含全部模块。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "module": {
            "type": "string",
            "minLength": 1,
            "maxLength": 64,
            "description": "只取这个模块的状态；省略时取全部"
          }
        },
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "cycles": {
            "type": "integer",
            "minimum": 0,
            "description": "自上电以来的 CPU 周期数"
          },
          "states": {
            "type": "array",
            "items": {
              "$ref": "#/types/ModuleState"
            },
            "description": "各模块的状态"
          },
          "breakpoints": {
            "type": "array",
            "items": {
              "$ref": "#/types/Breakpoint"
            },
            "description": "全部断点"
          },
          "watches": {
            "type": "array",
            "items": {
              "$ref": "#/types/WatchedValue"
            },
            "description": "全部监视项与当前取值"
          }
        },
        "required": [
          "cycles",
          "states",
          "breakpoints",
          "watches"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.invalidState"
      ]
    },
    "watch": {
      "description": "监视一个状态项：它的取值变化时发事件 inspector.stateChanged。路径是 <模块>.<状态项>，如 cpu.pc、ppu.scanline、mapper.prgBank（状态项见 getState）。取值在每一帧完成后、单步、命中断点和检查请求执行完之后检查，一帧里变化多次只报告最后的取值。已经在监视的路径再监视没有效果。监视最多 64 项，属于检查器本身，不随卡带更换清除。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "path": {
            "type": "string",
            "minLength": 3,
            "maxLength": 128,
            "description": "状态路径"
          }
        },
        "required": [
          "path"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "watch": {
            "$ref": "#/types/WatchedValue",
            "description": "监视项与当前取值"
          }
        },
        "required": [
          "watch"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.invalidState",
        "inspector.watchLimit"
      ]
    },
    "unwatch": {
      "description": "取消监视。没有监视这个路径时返回 inspector.noWatch。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "path": {
            "type": "string",
            "minLength": 3,
            "maxLength": 128,
            "description": "状态路径"
          }
        },
        "required": [
          "path"
        ]
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.noWatch"
      ]
    },
    "disassemble": {
      "description": "从 address 起反汇编 count 条指令（CPU 总线上的地址）。读内存没有副作用；带索引的寻址用当前的 X、Y 算有效地址与注释里的取值；地址超过 $FFFF 时回到 $0000。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "address": {
            "type": "integer",
            "minimum": 0,
            "maximum": 65535,
            "description": "起始地址"
          },
          "count": {
            "type": "integer",
            "minimum": 1,
            "maximum": 256,
            "description": "指令条数，默认 16"
          }
        },
        "required": [
          "address"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "instructions": {
            "type": "array",
            "items": {
              "$ref": "#/types/DisassembledInstruction"
            },
            "description": "反汇编的指令"
          }
        },
        "required": [
          "instructions"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported"
      ]
    },
    "cdlStart": {
      "description": "开始代码与数据标记（CDL）：给卡带 PRG-ROM 的每个字节打标记，标记清零后，运行与单步执行的每条指令都记：Code（0x01，被当作指令执行，含操作数字节）、Data（0x02，被指令当数据读取，不含只写的存储指令、栈与中断向量）、JumpTarget（0x04，JMP 或成立的分支的目标）、SubEntry（0x08，JSR 的目标）。标记的是物理位置（按当前的分页换算）。记录属于当前的主机，装入新卡带后作废。需要已开机，卡带要有 PRG-ROM 存储区。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "size": {
            "type": "integer",
            "minimum": 1,
            "description": "PRG-ROM 的字节数，也是标记的字节数"
          }
        },
        "required": [
          "size"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.cdlActive"
      ]
    },
    "cdlStop": {
      "description": "停止标记，已有的标记保留到下一次 cdlStart 或换卡带；已经停止时只返回统计。没有记录过时返回 inspector.noCdl。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "size": {
            "type": "integer",
            "minimum": 1,
            "description": "PRG-ROM 的字节数"
          },
          "codeBytes": {
            "type": "integer",
            "minimum": 0,
            "description": "标了 Code 的字节数"
          },
          "dataBytes": {
            "type": "integer",
            "minimum": 0,
            "description": "标了 Data 的字节数"
          }
        },
        "required": [
          "size",
          "codeBytes",
          "dataBytes"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.noCdl"
      ]
    },
    "cdlSave": {
      "description": "把当前的标记写成调试输出目录下的文件：PRG-ROM 每个字节一个标记字节，没有文件头，位定义同 Mesen。记录中或停止后都可以保存。没有记录过时返回 inspector.noCdl。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "file": {
            "type": "string",
            "minLength": 1,
            "maxLength": 100,
            "description": "文件名，只能含字母、数字、点、下划线、短横线与空格，不含目录；省略时用 prg.cdl"
          }
        },
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "file": {
            "type": "string",
            "description": "保存的文件的完整路径"
          },
          "size": {
            "type": "integer",
            "minimum": 1,
            "description": "PRG-ROM 的字节数，也是文件的字节数"
          },
          "codeBytes": {
            "type": "integer",
            "minimum": 0,
            "description": "标了 Code 的字节数"
          },
          "dataBytes": {
            "type": "integer",
            "minimum": 0,
            "description": "标了 Data 的字节数"
          }
        },
        "required": [
          "file",
          "size",
          "codeBytes",
          "dataBytes"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.noCdl",
        "inspector.invalidFileName",
        "inspector.fileFailed"
      ]
    },
    "traceStart": {
      "description": "开始跟踪，内容记在内存里，traceStop 时写成调试输出目录下的文件。kind：instruction 每执行一条指令记一行（地址、指令字节、反汇编、寄存器与周期数，写法同 nestest 日志；芯片寄存器的取值显示 00）；io 每次访问 $2000-$5FFF（芯片、手柄口、卡带扩展寄存器）以及对 $8000 以上的写（mapper 寄存器）记一行（方向、地址、值、发起访问的指令地址与周期数）；irq 每次 CPU 响应 IRQ、NMI 或 BRK 记一行（种类、返回地址、处理程序地址、周期数）。单步与运行产生的内容都记，调试写内存不记。同时进行的记录最多 8 项，记录属于当前的主机，装入新卡带后作废。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "kind": {
            "type": "string",
            "enum": [
              "instruction",
              "io",
              "irq"
            ],
            "description": "跟踪的种类"
          },
          "file": {
            "type": "string",
            "minLength": 1,
            "maxLength": 100,
            "description": "文件名，只能含字母、数字、点、下划线、短横线与空格，不含目录；省略时按种类与编号生成（trace-编号.txt、calllog-编号.txt）。文件写在调试输出目录"
          },
          "maxLines": {
            "type": "integer",
            "minimum": 1,
            "maximum": 1000000,
            "description": "最多记录的行数，满了就不再记录，默认 100000"
          },
          "unique": {
            "type": "boolean",
            "description": "只对 instruction 有效：每个地址只记第一次，默认 false"
          }
        },
        "required": [
          "kind"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "id": {
            "type": "integer",
            "minimum": 1,
            "description": "记录编号"
          }
        },
        "required": [
          "id"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.invalidFileName",
        "inspector.recordingLimit"
      ]
    },
    "traceStop": {
      "description": "结束跟踪并把内容写成文件。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "id": {
            "type": "integer",
            "minimum": 1,
            "description": "traceStart 返回的记录编号"
          }
        },
        "required": [
          "id"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "file": {
            "type": "string",
            "description": "保存的文件的完整路径"
          },
          "lines": {
            "type": "integer",
            "minimum": 0,
            "description": "写入的行数"
          },
          "truncated": {
            "type": "boolean",
            "description": "是否因为行数满了而少记了"
          }
        },
        "required": [
          "file",
          "lines",
          "truncated"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.noRecording",
        "inspector.fileFailed"
      ]
    },
    "callLogStart": {
      "description": "开始调用记录：每次执行到 address 这条指令之前记一行，含寄存器、周期数、栈顶的若干字节（SP 之上，栈顶在前）与指定的内存段。内容记在内存里，callLogStop 时写成调试输出目录下的文件。同时进行的记录最多 8 项，记录属于当前的主机，装入新卡带后作废。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "address": {
            "type": "integer",
            "minimum": 0,
            "maximum": 65535,
            "description": "要记录的指令地址"
          },
          "stackBytes": {
            "type": "integer",
            "minimum": 0,
            "maximum": 32,
            "description": "每次记录栈顶的字节数，默认 0"
          },
          "ranges": {
            "type": "array",
            "items": {
              "$ref": "#/types/MemoryRangeSpec"
            },
            "maxItems": 4,
            "description": "每次记录的内存段，最多 4 段"
          },
          "skip": {
            "type": "array",
            "items": {
              "$ref": "#/types/ByteCondition"
            },
            "maxItems": 4,
            "description": "跳过条件，最多 4 项：执行到这条指令时，任何一项成立（这个地址上的字节等于这个值）就不记录这一次，用来滤掉不关心的调用"
          },
          "file": {
            "type": "string",
            "minLength": 1,
            "maxLength": 100,
            "description": "文件名，只能含字母、数字、点、下划线、短横线与空格，不含目录；省略时按种类与编号生成（trace-编号.txt、calllog-编号.txt）。文件写在调试输出目录"
          },
          "maxLines": {
            "type": "integer",
            "minimum": 1,
            "maximum": 1000000,
            "description": "最多记录的行数，满了就不再记录，默认 100000"
          }
        },
        "required": [
          "address"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "id": {
            "type": "integer",
            "minimum": 1,
            "description": "记录编号"
          }
        },
        "required": [
          "id"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.invalidFileName",
        "inspector.recordingLimit"
      ]
    },
    "callLogStop": {
      "description": "结束调用记录并把内容写成文件。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "id": {
            "type": "integer",
            "minimum": 1,
            "description": "callLogStart 返回的记录编号"
          }
        },
        "required": [
          "id"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "file": {
            "type": "string",
            "description": "保存的文件的完整路径"
          },
          "lines": {
            "type": "integer",
            "minimum": 0,
            "description": "写入的行数"
          },
          "truncated": {
            "type": "boolean",
            "description": "是否因为行数满了而少记了"
          }
        },
        "required": [
          "file",
          "lines",
          "truncated"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.noRecording",
        "inspector.fileFailed"
      ]
    },
    "addBreakpoint": {
      "description": "添加断点。断点在机器运行时生效（自由运行与 runtime.run 都会停下，发事件 runtime.breakpointHit，运行模式变为暂停）；单步（runtime.step）忽略断点；继续运行时会先越过刚命中的执行断点。断点属于当前的主机，装入新卡带后清空。地址是 CPU 总线上的地址。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "kind": {
            "type": "string",
            "enum": [
              "execute",
              "read",
              "write"
            ],
            "description": "种类"
          },
          "address": {
            "type": "integer",
            "minimum": 0,
            "maximum": 65535,
            "description": "地址，或地址范围的第一个地址"
          },
          "endAddress": {
            "type": "integer",
            "minimum": 0,
            "maximum": 65535,
            "description": "地址范围的最后一个地址（含），省略时只有 address 一个地址"
          }
        },
        "required": [
          "kind",
          "address"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "breakpoint": {
            "$ref": "#/types/Breakpoint",
            "description": "添加的断点"
          }
        },
        "required": [
          "breakpoint"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.invalidBreakpoint",
        "inspector.breakpointLimit"
      ]
    },
    "listBreakpoints": {
      "description": "列出全部断点，按编号升序。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "breakpoints": {
            "type": "array",
            "items": {
              "$ref": "#/types/Breakpoint"
            },
            "description": "断点"
          }
        },
        "required": [
          "breakpoints"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported"
      ]
    },
    "removeBreakpoint": {
      "description": "删除一个断点。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "id": {
            "type": "integer",
            "minimum": 1,
            "description": "断点编号"
          }
        },
        "required": [
          "id"
        ]
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.noBreakpoint"
      ]
    },
    "clearBreakpoints": {
      "description": "删除全部断点。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "removed": {
            "type": "integer",
            "minimum": 0,
            "description": "删除的个数"
          }
        },
        "required": [
          "removed"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported"
      ]
    },
    "setState": {
      "description": "修改一个模块的状态：目前只有 cpu 可以改（pc、a、x、y、sp、status，只在指令之间生效），其余模块只读。先全部检查，有任何一项不合格就一项也不改。需要已开机。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "module": {
            "type": "string",
            "minLength": 1,
            "maxLength": 64,
            "description": "模块标识"
          },
          "fields": {
            "type": "array",
            "items": {
              "$ref": "#/types/StateField"
            },
            "minItems": 1,
            "maxItems": 16,
            "description": "要修改的状态项"
          }
        },
        "required": [
          "module",
          "fields"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "state": {
            "$ref": "#/types/ModuleState",
            "description": "修改之后的状态"
          }
        },
        "required": [
          "state"
        ]
      },
      "errors": [
        "inspector.noCartridge",
        "inspector.notPowered",
        "inspector.unsupported",
        "inspector.readOnly",
        "inspector.invalidState"
      ]
    }
  },
  "mainRequests": {},
  "events": {
    "stateChanged": {
      "description": "监视的状态项取值变了。同一次检查里变化的各项依次发出；监视项属于检查器，重新上电或换卡带之后的变化也会报告。",
      "data": {
        "type": "object",
        "properties": {
          "path": {
            "type": "string",
            "description": "状态路径"
          },
          "oldValue": {
            "type": "integer",
            "description": "上一次检查时的取值"
          },
          "newValue": {
            "type": "integer",
            "description": "现在的取值"
          },
          "cycles": {
            "type": "integer",
            "minimum": 0,
            "description": "检查时的 CPU 周期数"
          }
        },
        "required": [
          "path",
          "oldValue",
          "newValue",
          "cycles"
        ]
      }
    }
  }
};
