// 由 tools/schema-gen/schema-gen.mjs 根据 schema/mappers.schema.json 生成，不要手改。
/* eslint-disable */


import type { ModuleSchema } from '../../../shared/schema/schema-types';

/** 一项匹配条件：mapper 号必写，其余可选；写出的条件必须全部满足。 */
export interface MapperMatchRule {
  /** mapper 号 */
  mapper: number;
  /** 变体 */
  variant?: number;
  /** PRG 的字节数 */
  prgSize?: number;
  /** CHR 的字节数 */
  chrSize?: number;
  /** PRG 的 CRC-32，8 位十六进制 */
  crc32Prg?: string;
  /** PRG 加 CHR 的 CRC-32，8 位十六进制 */
  crc32All?: string;
}

/** 插件摘要，列表里的一行。 */
export interface MapperSummary {
  /** 插件标识 */
  id: string;
  /** 显示名称 */
  name: string;
  /** 插件版本，主.次.修订 */
  version: string;
  /** 发布者 */
  publisher: string;
  /** 说明 */
  description?: string;
  /** 要求的主机型号 */
  host: string[];
  /** 卡带用到的外设，目前只有 mouse（鼠标）；没有声明的外设，界面不会把它接到卡带上 */
  devices: Array<"mouse">;
  /** 匹配条件，任一项满足即匹配 */
  match: MapperMatchRule[];
  /** 来源：bundled 预装，user 用户安装 */
  source: "bundled" | "user";
  /** 是否启用 */
  enabled: boolean;
}

/** 清单里的一个存储区。 */
export interface MapperStorageInfo {
  /** 存储区标识 */
  id: string;
  /** 种类 */
  kind: "rom" | "ram";
  /** rom 的数据来源 */
  from?: "file.prg" | "file.chr";
  /** ram 的字节数 */
  size?: number;
  /** ram 是否带电池 */
  battery: boolean;
  /** 来源为空时改用的 ram 的字节数 */
  fallbackSize?: number;
}

/** 清单里的一个窗口。 */
export interface MapperWindowInfo {
  /** 窗口标识 */
  id: string;
  /** 所在总线 */
  bus: "cpu" | "ppu";
  /** 地址范围，如 $8000-$9FFF */
  range: string;
  /** 访问的存储区 */
  storage: string;
  /** 一个 bank 的字节数 */
  size: number;
  /** 复位后指向的 bank：整数、first 或 last */
  initial: string;
  /** 访问方式 */
  access: "r" | "rw";
}

/** 清单里的一段寄存器范围。 */
export interface MapperRegisterInfo {
  /** 所在总线 */
  bus: "cpu" | "ppu";
  /** 地址范围 */
  range: string;
  /** 是否回调读 */
  read: boolean;
  /** 是否回调写 */
  write: boolean;
}

/** 清单里声明的一项脚本状态。 */
export interface MapperStateInfo {
  /** 状态名 */
  name: string;
  /** 位宽 */
  bits: number;
  /** 说明 */
  description: string;
}

/** choice 设置项的一个选项。 */
export interface MapperSettingOption {
  /** 取值 */
  value: string;
  /** 显示文字 */
  label: string;
}

/** 清单里的一个设置项。 */
export interface MapperSettingInfo {
  /** 设置键 */
  key: string;
  /** 显示文字 */
  label: string;
  /** 种类 */
  kind: "text" | "choice" | "switch";
  /** 默认值：text 与 choice 为字符串，switch 为布尔值 */
  defaultValue: unknown;
  /** 说明 */
  description?: string;
  /** choice 的选项 */
  options?: MapperSettingOption[];
}

/** 插件详情：摘要加清单的各部分。 */
export interface MapperDetail {
  summary: MapperSummary;
  /** 存储区 */
  storage: MapperStorageInfo[];
  /** 窗口 */
  windows: MapperWindowInfo[];
  /** 名称表的初始连法 */
  nametable: string;
  /** 寄存器范围 */
  registers: MapperRegisterInfo[];
  /** 脚本状态 */
  state: MapperStateInfo[];
  /** 设置项 */
  settings: MapperSettingInfo[];
}

export type MappersListParams = Record<string, never>;

export interface MappersListResult {
  /** 插件摘要，按标识排序 */
  plugins: MapperSummary[];
}

export interface MappersInfoParams {
  /** 插件标识 */
  id: string;
}

export interface MappersInfoResult {
  plugin: MapperDetail;
}

export interface MappersInstallParams {
  /** 插件包的文件路径，由主进程根据用户选择的文件给出 */
  path: string;
}

export interface MappersInstallResult {
  plugin: MapperSummary;
}

export interface MappersUninstallParams {
  /** 插件标识 */
  id: string;
}

export type MappersUninstallResult = Record<string, never>;

export interface MappersSetEnabledParams {
  /** 插件标识 */
  id: string;
  /** 是否启用 */
  enabled: boolean;
}

export interface MappersSetEnabledResult {
  plugin: MapperSummary;
}

export type MappersReloadParams = Record<string, never>;

export interface MappersReloadResult {
  /** 重新加载后生效的插件摘要 */
  plugins: MapperSummary[];
}

export type MappersOpenPackageParams = Record<string, never>;

export interface MappersOpenPackageResult {
  /** 用户是否取消了选择 */
  canceled: boolean;
  /** 安装后的插件摘要；取消时没有这一项 */
  plugin?: MapperSummary;
}

export interface MappersChangedData {
  /** 变化的插件标识；重新加载时为 null */
  id: string | null;
}

/** 本模块的请求名。 */
export const MAPPERS_REQUESTS = {
  list: 'mappers.list',
  info: 'mappers.info',
  install: 'mappers.install',
  uninstall: 'mappers.uninstall',
  setEnabled: 'mappers.setEnabled',
  reload: 'mappers.reload'
} as const;

/** 本模块由主进程处理的请求名。 */
export const MAPPERS_MAIN_REQUESTS = {
  openPackage: 'mappers.openPackage'
} as const;

/** 本模块的事件名。 */
export const MAPPERS_EVENTS = {
  changed: 'mappers.changed'
} as const;

/** 请求名到参数与结果类型的对照。 */
export interface MappersRequestMap {
  'mappers.list': { params: MappersListParams; result: MappersListResult };
  'mappers.info': { params: MappersInfoParams; result: MappersInfoResult };
  'mappers.install': { params: MappersInstallParams; result: MappersInstallResult };
  'mappers.uninstall': { params: MappersUninstallParams; result: MappersUninstallResult };
  'mappers.setEnabled': { params: MappersSetEnabledParams; result: MappersSetEnabledResult };
  'mappers.reload': { params: MappersReloadParams; result: MappersReloadResult };
}

/** 主进程处理的请求名到参数与结果类型的对照。 */
export interface MappersMainRequestMap {
  'mappers.openPackage': { params: MappersOpenPackageParams; result: MappersOpenPackageResult };
}

/** 事件名到数据类型的对照。 */
export interface MappersEventMap {
  'mappers.changed': MappersChangedData;
}

/** 本模块的 Schema，供入口校验使用。 */
export const MAPPERS_SCHEMA: ModuleSchema = {
  "module": "mappers",
  "types": {
    "MapperMatchRule": {
      "type": "object",
      "description": "一项匹配条件：mapper 号必写，其余可选；写出的条件必须全部满足。",
      "properties": {
        "mapper": {
          "type": "integer",
          "minimum": 0,
          "maximum": 4095,
          "description": "mapper 号"
        },
        "variant": {
          "type": "integer",
          "minimum": 0,
          "maximum": 255,
          "description": "变体"
        },
        "prgSize": {
          "type": "integer",
          "minimum": 0,
          "description": "PRG 的字节数"
        },
        "chrSize": {
          "type": "integer",
          "minimum": 0,
          "description": "CHR 的字节数"
        },
        "crc32Prg": {
          "type": "string",
          "minLength": 8,
          "maxLength": 8,
          "description": "PRG 的 CRC-32，8 位十六进制"
        },
        "crc32All": {
          "type": "string",
          "minLength": 8,
          "maxLength": 8,
          "description": "PRG 加 CHR 的 CRC-32，8 位十六进制"
        }
      },
      "required": [
        "mapper"
      ]
    },
    "MapperSummary": {
      "type": "object",
      "description": "插件摘要，列表里的一行。",
      "properties": {
        "id": {
          "type": "string",
          "minLength": 3,
          "maxLength": 40,
          "description": "插件标识"
        },
        "name": {
          "type": "string",
          "minLength": 1,
          "maxLength": 40,
          "description": "显示名称"
        },
        "version": {
          "type": "string",
          "minLength": 5,
          "maxLength": 32,
          "description": "插件版本，主.次.修订"
        },
        "publisher": {
          "type": "string",
          "minLength": 1,
          "maxLength": 40,
          "description": "发布者"
        },
        "description": {
          "type": "string",
          "maxLength": 200,
          "description": "说明"
        },
        "host": {
          "type": "array",
          "items": {
            "type": "string"
          },
          "description": "要求的主机型号"
        },
        "devices": {
          "type": "array",
          "items": {
            "type": "string",
            "enum": [
              "mouse"
            ]
          },
          "description": "卡带用到的外设，目前只有 mouse（鼠标）；没有声明的外设，界面不会把它接到卡带上"
        },
        "match": {
          "type": "array",
          "items": {
            "$ref": "#/types/MapperMatchRule"
          },
          "description": "匹配条件，任一项满足即匹配"
        },
        "source": {
          "type": "string",
          "enum": [
            "bundled",
            "user"
          ],
          "description": "来源：bundled 预装，user 用户安装"
        },
        "enabled": {
          "type": "boolean",
          "description": "是否启用"
        }
      },
      "required": [
        "id",
        "name",
        "version",
        "publisher",
        "host",
        "devices",
        "match",
        "source",
        "enabled"
      ]
    },
    "MapperStorageInfo": {
      "type": "object",
      "description": "清单里的一个存储区。",
      "properties": {
        "id": {
          "type": "string",
          "description": "存储区标识"
        },
        "kind": {
          "type": "string",
          "enum": [
            "rom",
            "ram"
          ],
          "description": "种类"
        },
        "from": {
          "type": "string",
          "enum": [
            "file.prg",
            "file.chr"
          ],
          "description": "rom 的数据来源"
        },
        "size": {
          "type": "integer",
          "minimum": 0,
          "description": "ram 的字节数"
        },
        "battery": {
          "type": "boolean",
          "description": "ram 是否带电池"
        },
        "fallbackSize": {
          "type": "integer",
          "minimum": 0,
          "description": "来源为空时改用的 ram 的字节数"
        }
      },
      "required": [
        "id",
        "kind",
        "battery"
      ]
    },
    "MapperWindowInfo": {
      "type": "object",
      "description": "清单里的一个窗口。",
      "properties": {
        "id": {
          "type": "string",
          "description": "窗口标识"
        },
        "bus": {
          "type": "string",
          "enum": [
            "cpu",
            "ppu"
          ],
          "description": "所在总线"
        },
        "range": {
          "type": "string",
          "description": "地址范围，如 $8000-$9FFF"
        },
        "storage": {
          "type": "string",
          "description": "访问的存储区"
        },
        "size": {
          "type": "integer",
          "minimum": 1,
          "description": "一个 bank 的字节数"
        },
        "initial": {
          "type": "string",
          "description": "复位后指向的 bank：整数、first 或 last"
        },
        "access": {
          "type": "string",
          "enum": [
            "r",
            "rw"
          ],
          "description": "访问方式"
        }
      },
      "required": [
        "id",
        "bus",
        "range",
        "storage",
        "size",
        "initial",
        "access"
      ]
    },
    "MapperRegisterInfo": {
      "type": "object",
      "description": "清单里的一段寄存器范围。",
      "properties": {
        "bus": {
          "type": "string",
          "enum": [
            "cpu",
            "ppu"
          ],
          "description": "所在总线"
        },
        "range": {
          "type": "string",
          "description": "地址范围"
        },
        "read": {
          "type": "boolean",
          "description": "是否回调读"
        },
        "write": {
          "type": "boolean",
          "description": "是否回调写"
        }
      },
      "required": [
        "bus",
        "range",
        "read",
        "write"
      ]
    },
    "MapperStateInfo": {
      "type": "object",
      "description": "清单里声明的一项脚本状态。",
      "properties": {
        "name": {
          "type": "string",
          "description": "状态名"
        },
        "bits": {
          "type": "integer",
          "minimum": 1,
          "maximum": 32,
          "description": "位宽"
        },
        "description": {
          "type": "string",
          "description": "说明"
        }
      },
      "required": [
        "name",
        "bits",
        "description"
      ]
    },
    "MapperSettingOption": {
      "type": "object",
      "description": "choice 设置项的一个选项。",
      "properties": {
        "value": {
          "type": "string",
          "description": "取值"
        },
        "label": {
          "type": "string",
          "description": "显示文字"
        }
      },
      "required": [
        "value",
        "label"
      ]
    },
    "MapperSettingInfo": {
      "type": "object",
      "description": "清单里的一个设置项。",
      "properties": {
        "key": {
          "type": "string",
          "description": "设置键"
        },
        "label": {
          "type": "string",
          "description": "显示文字"
        },
        "kind": {
          "type": "string",
          "enum": [
            "text",
            "choice",
            "switch"
          ],
          "description": "种类"
        },
        "defaultValue": {
          "description": "默认值：text 与 choice 为字符串，switch 为布尔值"
        },
        "description": {
          "type": "string",
          "description": "说明"
        },
        "options": {
          "type": "array",
          "items": {
            "$ref": "#/types/MapperSettingOption"
          },
          "description": "choice 的选项"
        }
      },
      "required": [
        "key",
        "label",
        "kind",
        "defaultValue"
      ]
    },
    "MapperDetail": {
      "type": "object",
      "description": "插件详情：摘要加清单的各部分。",
      "properties": {
        "summary": {
          "$ref": "#/types/MapperSummary"
        },
        "storage": {
          "type": "array",
          "items": {
            "$ref": "#/types/MapperStorageInfo"
          },
          "description": "存储区"
        },
        "windows": {
          "type": "array",
          "items": {
            "$ref": "#/types/MapperWindowInfo"
          },
          "description": "窗口"
        },
        "nametable": {
          "type": "string",
          "description": "名称表的初始连法"
        },
        "registers": {
          "type": "array",
          "items": {
            "$ref": "#/types/MapperRegisterInfo"
          },
          "description": "寄存器范围"
        },
        "state": {
          "type": "array",
          "items": {
            "$ref": "#/types/MapperStateInfo"
          },
          "description": "脚本状态"
        },
        "settings": {
          "type": "array",
          "items": {
            "$ref": "#/types/MapperSettingInfo"
          },
          "description": "设置项"
        }
      },
      "required": [
        "summary",
        "storage",
        "windows",
        "nametable",
        "registers",
        "state",
        "settings"
      ]
    }
  },
  "requests": {
    "list": {
      "description": "列出生效的插件：同一标识有多个来源时只列版本最高的，版本相同时用户安装的优先。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "plugins": {
            "type": "array",
            "items": {
              "$ref": "#/types/MapperSummary"
            },
            "description": "插件摘要，按标识排序"
          }
        },
        "required": [
          "plugins"
        ]
      }
    },
    "info": {
      "description": "返回一个插件的摘要与清单详情。",
      "params": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 40,
            "description": "插件标识"
          }
        },
        "required": [
          "id"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "plugin": {
            "$ref": "#/types/MapperDetail"
          }
        },
        "required": [
          "plugin"
        ]
      },
      "errors": [
        "mappers.notFound"
      ]
    },
    "install": {
      "description": "安装一个 .emap 插件包：检查通过后放进用户插件目录；已有同标识的用户插件时替换。",
      "mainOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "path": {
            "type": "string",
            "minLength": 1,
            "description": "插件包的文件路径，由主进程根据用户选择的文件给出"
          }
        },
        "required": [
          "path"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "plugin": {
            "$ref": "#/types/MapperSummary"
          }
        },
        "required": [
          "plugin"
        ]
      },
      "errors": [
        "mappers.invalidPackage",
        "mappers.hostUnknown",
        "mappers.limitExceeded"
      ]
    },
    "uninstall": {
      "description": "卸载用户安装的插件；预装的插件只能停用。",
      "params": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 40,
            "description": "插件标识"
          }
        },
        "required": [
          "id"
        ]
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": [
        "mappers.notFound",
        "mappers.bundledReadonly"
      ]
    },
    "setEnabled": {
      "description": "启用或停用一个插件；停用的插件不参与匹配。",
      "params": {
        "type": "object",
        "properties": {
          "id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 40,
            "description": "插件标识"
          },
          "enabled": {
            "type": "boolean",
            "description": "是否启用"
          }
        },
        "required": [
          "id",
          "enabled"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "plugin": {
            "$ref": "#/types/MapperSummary"
          }
        },
        "required": [
          "plugin"
        ]
      },
      "errors": [
        "mappers.notFound"
      ]
    },
    "reload": {
      "description": "重新读取预装目录与用户目录里的插件包，下次装配或硬复位时生效；不合格的包被跳过并写入错误日志。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "plugins": {
            "type": "array",
            "items": {
              "$ref": "#/types/MapperSummary"
            },
            "description": "重新加载后生效的插件摘要"
          }
        },
        "required": [
          "plugins"
        ]
      }
    }
  },
  "mainRequests": {
    "openPackage": {
      "description": "弹出系统文件选择窗口（.emap 插件包），把用户选定的文件交给 mappers.install；用户取消选择时 canceled 为 true，不是错误。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "canceled": {
            "type": "boolean",
            "description": "用户是否取消了选择"
          },
          "plugin": {
            "$ref": "#/types/MapperSummary",
            "description": "安装后的插件摘要；取消时没有这一项"
          }
        },
        "required": [
          "canceled"
        ]
      },
      "errors": [
        "mappers.invalidPackage",
        "mappers.hostUnknown",
        "mappers.limitExceeded"
      ]
    }
  },
  "events": {
    "changed": {
      "description": "插件安装、卸载、启停或重新加载。",
      "data": {
        "type": "object",
        "properties": {
          "id": {
            "type": [
              "string",
              "null"
            ],
            "description": "变化的插件标识；重新加载时为 null"
          }
        },
        "required": [
          "id"
        ]
      }
    }
  }
};
