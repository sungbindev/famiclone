// 由 tools/schema-gen/schema-gen.mjs 根据 schema/media.schema.json 生成，不要手改。
/* eslint-disable */


import type { ModuleSchema } from '../../../shared/schema/schema-types';

/** 软驱上注入的故障；全部关闭是正常状态。 */
export interface FloppyFaults {
  /** 取盘：盘片被暂时取出（镜像还在，放回后内容不变） */
  ejected: boolean;
  /** 没有索引脉冲：读扇区编号、读写与格式化命令一直不结束 */
  noIndex: boolean;
  /** 磁头卡住：寻道与回零不移动 */
  seekFail: boolean;
  /** 控制器无响应：收到命令字节后不再处理 */
  unresponsive: boolean;
  /** 读时数据校验出错的逻辑扇区号 */
  badSectors: number[];
}

/** 一个软驱的状态。 */
export interface FloppyStatus {
  /** 驱动器编号，从 0 开始 */
  drive: number;
  /** 里面有没有盘片 */
  inserted: boolean;
  /** 盘片来源的文件名，不含路径；没有盘片时没有这一项 */
  fileName?: string;
  /** 盘片是否写保护 */
  writeProtected: boolean;
  /** 镜像是否有尚未写回文件的修改（学习机写盘后置位，核心自动写回后清除） */
  modified: boolean;
  /** 镜像的大小（字节）；没有盘片时为 0 */
  size: number;
  /** 磁头所在的磁道 */
  cylinder: number;
  /** 马达是否在转 */
  motor: boolean;
  faults: FloppyFaults;
}

/** 并口打印机的状态。 */
export interface PrinterStatus {
  /** 状态：idle 空闲（机器没有运行，或还没有内容），printing 打印中（当前页上有内容），done 打印完成（输出过一页且下一页还没有内容） */
  state: "idle" | "printing" | "done";
  /** 当前页上是否已经有内容 */
  hasContent: boolean;
  /** 本次运行以来已输出的页数 */
  pages: number;
  /** 最近一页的文件名，不含路径；还没有输出过时没有这一项 */
  lastFile?: string;
}

/** 磁带机的状态。 */
export interface TapeStatus {
  /** 磁带机是否接在通电的主机上（主机通电且有磁带接口）；没接上时可以载入与取出磁带，但不能播放与录音 */
  connected: boolean;
  /** 里面有没有磁带 */
  loaded: boolean;
  /** 磁带（声音文件）的文件名，不含路径；没有磁带时没有这一项 */
  fileName?: string;
  /** 工作状态：stopped 停止，playing 播放，recording 录音 */
  mode: "stopped" | "playing" | "recording";
  /** 当前位置（秒）；录音时是已录的时长 */
  position: number;
  /** 总时长（秒）；不知道或没有磁带时为 0 */
  duration: number;
  /** 是否是立体声磁带：是则左声道是声音、右声道是数据；否则整路是数据，不出声 */
  stereo: boolean;
}

export interface MediaFloppyInsertParams {
  /** 驱动器编号 */
  drive: number;
  /** 镜像文件的路径 */
  path: string;
  /** 是否写保护，默认 false */
  writeProtected?: boolean;
}

export interface MediaFloppyInsertResult {
  status: FloppyStatus;
}

export interface MediaFloppyEjectParams {
  /** 驱动器编号 */
  drive: number;
}

export interface MediaFloppyEjectResult {
  status: FloppyStatus;
}

export interface MediaFloppySaveParams {
  /** 驱动器编号 */
  drive: number;
}

export interface MediaFloppySaveResult {
  status: FloppyStatus;
}

export interface MediaFloppyWriteProtectParams {
  /** 驱动器编号 */
  drive: number;
  /** 是否写保护 */
  writeProtected: boolean;
}

export interface MediaFloppyWriteProtectResult {
  status: FloppyStatus;
}

export type MediaFloppyStatusParams = Record<string, never>;

export interface MediaFloppyStatusResult {
  /** 各驱动器的状态，按编号排列 */
  drives: FloppyStatus[];
}

export interface MediaFloppyFaultParams {
  /** 驱动器编号 */
  drive: number;
  /** 故障：ejected 取盘（放回时内容不变），writeProtected 写保护，noIndex 无索引脉冲，seekFail 磁头卡住，unresponsive 控制器无响应，badSector 指定扇区校验错，clear 关闭全部故障、放回盘片、取消写保护 */
  fault: "ejected" | "writeProtected" | "noIndex" | "seekFail" | "unresponsive" | "badSector" | "clear";
  /** 打开还是关闭这个故障，默认 true；clear 不用这一项 */
  enabled?: boolean;
  /** badSector 的逻辑扇区号（磁道×每道扇区数×面数 + 磁头×每道扇区数 + 扇区号 - 1），badSector 必填 */
  sector?: number;
}

export interface MediaFloppyFaultResult {
  status: FloppyStatus;
}

export type MediaPrinterStatusParams = Record<string, never>;

export interface MediaPrinterStatusResult {
  status: PrinterStatus;
}

export type MediaPrinterFlushParams = Record<string, never>;

export interface MediaPrinterFlushResult {
  status: PrinterStatus;
}

export interface MediaTapeLoadParams {
  /** 声音文件的路径 */
  path: string;
}

export interface MediaTapeLoadResult {
  status: TapeStatus;
}

export type MediaTapeEjectParams = Record<string, never>;

export interface MediaTapeEjectResult {
  status: TapeStatus;
}

export type MediaTapePlayParams = Record<string, never>;

export interface MediaTapePlayResult {
  status: TapeStatus;
}

export interface MediaTapeRecordParams {
  /** 录音文件的路径 */
  path: string;
}

export interface MediaTapeRecordResult {
  status: TapeStatus;
}

export type MediaTapeStopParams = Record<string, never>;

export interface MediaTapeStopResult {
  status: TapeStatus;
}

export type MediaTapeStatusParams = Record<string, never>;

export interface MediaTapeStatusResult {
  status: TapeStatus;
}

export interface MediaOpenFloppyParams {
  /** 驱动器编号 */
  drive: number;
  /** 拖入窗口的文件的编号（拖放时由主进程登记，路径只在主进程里）；不给时弹出文件选择窗口 */
  droppedId?: number;
}

export interface MediaOpenFloppyResult {
  /** 用户是否取消了选择 */
  canceled: boolean;
  /** 放入盘片后的驱动器状态；取消时没有这一项 */
  status?: FloppyStatus;
}

export interface MediaOpenTapeParams {
  /** 拖入窗口的文件的编号（拖放时由主进程登记，路径只在主进程里）；不给时弹出文件选择窗口 */
  droppedId?: number;
}

export interface MediaOpenTapeResult {
  /** 用户是否取消了选择 */
  canceled: boolean;
  /** 放入磁带后的磁带机状态；取消时没有这一项 */
  status?: TapeStatus;
}

export type MediaOpenTapeRecordingParams = Record<string, never>;

export interface MediaOpenTapeRecordingResult {
  /** 用户是否取消了选择 */
  canceled: boolean;
  /** 开始录音后的磁带机状态；取消时没有这一项 */
  status?: TapeStatus;
}

export interface MediaChangedData {
  /** 设备 */
  device: "floppy" | "tape";
  /** 驱动器编号；磁带机恒为 0 */
  drive: number;
}

export interface MediaPrintedData {
  /** 文件名，不含路径 */
  fileName: string;
  /** 本次运行以来的页序号 */
  page: number;
}

export interface MediaPrintFailedData {
  /** 原因，面向用户 */
  message: string;
}

export interface MediaFloppySaveFailedData {
  /** 驱动器编号 */
  drive: number;
  /** 原因，面向用户 */
  message: string;
}

/** 本模块的请求名。 */
export const MEDIA_REQUESTS = {
  floppyInsert: 'media.floppyInsert',
  floppyEject: 'media.floppyEject',
  floppySave: 'media.floppySave',
  floppyWriteProtect: 'media.floppyWriteProtect',
  floppyStatus: 'media.floppyStatus',
  floppyFault: 'media.floppyFault',
  printerStatus: 'media.printerStatus',
  printerFlush: 'media.printerFlush',
  tapeLoad: 'media.tapeLoad',
  tapeEject: 'media.tapeEject',
  tapePlay: 'media.tapePlay',
  tapeRecord: 'media.tapeRecord',
  tapeStop: 'media.tapeStop',
  tapeStatus: 'media.tapeStatus'
} as const;

/** 本模块由主进程处理的请求名。 */
export const MEDIA_MAIN_REQUESTS = {
  openFloppy: 'media.openFloppy',
  openTape: 'media.openTape',
  openTapeRecording: 'media.openTapeRecording'
} as const;

/** 本模块的事件名。 */
export const MEDIA_EVENTS = {
  changed: 'media.changed',
  printed: 'media.printed',
  printFailed: 'media.printFailed',
  floppySaveFailed: 'media.floppySaveFailed'
} as const;

/** 请求名到参数与结果类型的对照。 */
export interface MediaRequestMap {
  'media.floppyInsert': { params: MediaFloppyInsertParams; result: MediaFloppyInsertResult };
  'media.floppyEject': { params: MediaFloppyEjectParams; result: MediaFloppyEjectResult };
  'media.floppySave': { params: MediaFloppySaveParams; result: MediaFloppySaveResult };
  'media.floppyWriteProtect': { params: MediaFloppyWriteProtectParams; result: MediaFloppyWriteProtectResult };
  'media.floppyStatus': { params: MediaFloppyStatusParams; result: MediaFloppyStatusResult };
  'media.floppyFault': { params: MediaFloppyFaultParams; result: MediaFloppyFaultResult };
  'media.printerStatus': { params: MediaPrinterStatusParams; result: MediaPrinterStatusResult };
  'media.printerFlush': { params: MediaPrinterFlushParams; result: MediaPrinterFlushResult };
  'media.tapeLoad': { params: MediaTapeLoadParams; result: MediaTapeLoadResult };
  'media.tapeEject': { params: MediaTapeEjectParams; result: MediaTapeEjectResult };
  'media.tapePlay': { params: MediaTapePlayParams; result: MediaTapePlayResult };
  'media.tapeRecord': { params: MediaTapeRecordParams; result: MediaTapeRecordResult };
  'media.tapeStop': { params: MediaTapeStopParams; result: MediaTapeStopResult };
  'media.tapeStatus': { params: MediaTapeStatusParams; result: MediaTapeStatusResult };
}

/** 主进程处理的请求名到参数与结果类型的对照。 */
export interface MediaMainRequestMap {
  'media.openFloppy': { params: MediaOpenFloppyParams; result: MediaOpenFloppyResult };
  'media.openTape': { params: MediaOpenTapeParams; result: MediaOpenTapeResult };
  'media.openTapeRecording': { params: MediaOpenTapeRecordingParams; result: MediaOpenTapeRecordingResult };
}

/** 事件名到数据类型的对照。 */
export interface MediaEventMap {
  'media.changed': MediaChangedData;
  'media.printed': MediaPrintedData;
  'media.printFailed': MediaPrintFailedData;
  'media.floppySaveFailed': MediaFloppySaveFailedData;
}

/** 本模块的 Schema，供入口校验使用。 */
export const MEDIA_SCHEMA: ModuleSchema = {
  "module": "media",
  "types": {
    "FloppyFaults": {
      "type": "object",
      "description": "软驱上注入的故障；全部关闭是正常状态。",
      "properties": {
        "ejected": {
          "type": "boolean",
          "description": "取盘：盘片被暂时取出（镜像还在，放回后内容不变）"
        },
        "noIndex": {
          "type": "boolean",
          "description": "没有索引脉冲：读扇区编号、读写与格式化命令一直不结束"
        },
        "seekFail": {
          "type": "boolean",
          "description": "磁头卡住：寻道与回零不移动"
        },
        "unresponsive": {
          "type": "boolean",
          "description": "控制器无响应：收到命令字节后不再处理"
        },
        "badSectors": {
          "type": "array",
          "items": {
            "type": "integer",
            "minimum": 0
          },
          "description": "读时数据校验出错的逻辑扇区号"
        }
      },
      "required": [
        "ejected",
        "noIndex",
        "seekFail",
        "unresponsive",
        "badSectors"
      ]
    },
    "FloppyStatus": {
      "type": "object",
      "description": "一个软驱的状态。",
      "properties": {
        "drive": {
          "type": "integer",
          "minimum": 0,
          "description": "驱动器编号，从 0 开始"
        },
        "inserted": {
          "type": "boolean",
          "description": "里面有没有盘片"
        },
        "fileName": {
          "type": "string",
          "description": "盘片来源的文件名，不含路径；没有盘片时没有这一项"
        },
        "writeProtected": {
          "type": "boolean",
          "description": "盘片是否写保护"
        },
        "modified": {
          "type": "boolean",
          "description": "镜像是否有尚未写回文件的修改（学习机写盘后置位，核心自动写回后清除）"
        },
        "size": {
          "type": "integer",
          "minimum": 0,
          "description": "镜像的大小（字节）；没有盘片时为 0"
        },
        "cylinder": {
          "type": "integer",
          "minimum": 0,
          "description": "磁头所在的磁道"
        },
        "motor": {
          "type": "boolean",
          "description": "马达是否在转"
        },
        "faults": {
          "$ref": "#/types/FloppyFaults"
        }
      },
      "required": [
        "drive",
        "inserted",
        "writeProtected",
        "modified",
        "size",
        "cylinder",
        "motor",
        "faults"
      ]
    },
    "PrinterStatus": {
      "type": "object",
      "description": "并口打印机的状态。",
      "properties": {
        "state": {
          "type": "string",
          "enum": [
            "idle",
            "printing",
            "done"
          ],
          "description": "状态：idle 空闲（机器没有运行，或还没有内容），printing 打印中（当前页上有内容），done 打印完成（输出过一页且下一页还没有内容）"
        },
        "hasContent": {
          "type": "boolean",
          "description": "当前页上是否已经有内容"
        },
        "pages": {
          "type": "integer",
          "minimum": 0,
          "description": "本次运行以来已输出的页数"
        },
        "lastFile": {
          "type": "string",
          "description": "最近一页的文件名，不含路径；还没有输出过时没有这一项"
        }
      },
      "required": [
        "state",
        "hasContent",
        "pages"
      ]
    },
    "TapeStatus": {
      "type": "object",
      "description": "磁带机的状态。",
      "properties": {
        "connected": {
          "type": "boolean",
          "description": "磁带机是否接在通电的主机上（主机通电且有磁带接口）；没接上时可以载入与取出磁带，但不能播放与录音"
        },
        "loaded": {
          "type": "boolean",
          "description": "里面有没有磁带"
        },
        "fileName": {
          "type": "string",
          "description": "磁带（声音文件）的文件名，不含路径；没有磁带时没有这一项"
        },
        "mode": {
          "type": "string",
          "enum": [
            "stopped",
            "playing",
            "recording"
          ],
          "description": "工作状态：stopped 停止，playing 播放，recording 录音"
        },
        "position": {
          "type": "number",
          "minimum": 0,
          "description": "当前位置（秒）；录音时是已录的时长"
        },
        "duration": {
          "type": "number",
          "minimum": 0,
          "description": "总时长（秒）；不知道或没有磁带时为 0"
        },
        "stereo": {
          "type": "boolean",
          "description": "是否是立体声磁带：是则左声道是声音、右声道是数据；否则整路是数据，不出声"
        }
      },
      "required": [
        "connected",
        "loaded",
        "mode",
        "position",
        "duration",
        "stereo"
      ]
    }
  },
  "requests": {
    "floppyInsert": {
      "description": "读取盘片镜像文件（上限 16 MB）放进驱动器，替换已有的盘片；软驱是独立于主机的设备，没有主机、没有通电时也可以插入。镜像的格式由大小推断（160、180、320、360、720、1200、1440、2880 KB，其他大小按 1.44MB 处理）。",
      "mainOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "drive": {
            "type": "integer",
            "minimum": 0,
            "maximum": 3,
            "description": "驱动器编号"
          },
          "path": {
            "type": "string",
            "minLength": 1,
            "description": "镜像文件的路径"
          },
          "writeProtected": {
            "type": "boolean",
            "description": "是否写保护，默认 false"
          }
        },
        "required": [
          "drive",
          "path"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/FloppyStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": [
        "media.noDrive",
        "media.fileNotFound",
        "media.fileUnreadable",
        "media.imageInvalid",
        "media.saveFailed"
      ]
    },
    "floppyEject": {
      "description": "取出盘片并丢弃镜像；有尚未写回的修改时先写回放入时的文件，写回失败则不取出；没有盘片时没有效果。",
      "params": {
        "type": "object",
        "properties": {
          "drive": {
            "type": "integer",
            "minimum": 0,
            "maximum": 3,
            "description": "驱动器编号"
          }
        },
        "required": [
          "drive"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/FloppyStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": [
        "media.noDrive",
        "media.saveFailed"
      ]
    },
    "floppySave": {
      "description": "立即把驱动器里的镜像写回放入时的文件，并清除“已修改”标志；学习机写盘后核心会自动写回，通常不必调用。",
      "params": {
        "type": "object",
        "properties": {
          "drive": {
            "type": "integer",
            "minimum": 0,
            "maximum": 3,
            "description": "驱动器编号"
          }
        },
        "required": [
          "drive"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/FloppyStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": [
        "media.noDrive",
        "media.noDisk",
        "media.saveFailed"
      ]
    },
    "floppyWriteProtect": {
      "description": "设置或取消盘片的写保护；写保护的盘片拒绝学习机写入。",
      "params": {
        "type": "object",
        "properties": {
          "drive": {
            "type": "integer",
            "minimum": 0,
            "maximum": 3,
            "description": "驱动器编号"
          },
          "writeProtected": {
            "type": "boolean",
            "description": "是否写保护"
          }
        },
        "required": [
          "drive",
          "writeProtected"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/FloppyStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": [
        "media.noDrive"
      ]
    },
    "floppyStatus": {
      "description": "全部软驱的状态；软驱是独立于主机的设备，一直存在（目前只有软驱 A）。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "drives": {
            "type": "array",
            "items": {
              "$ref": "#/types/FloppyStatus"
            },
            "description": "各驱动器的状态，按编号排列"
          }
        },
        "required": [
          "drives"
        ]
      },
      "errors": []
    },
    "floppyFault": {
      "description": "故障注入：取盘、写保护、无索引脉冲、磁头卡住、控制器无响应、指定扇区校验错、全部清除；用来检查学习机程序对软驱故障的处理。",
      "debugOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "drive": {
            "type": "integer",
            "minimum": 0,
            "maximum": 3,
            "description": "驱动器编号"
          },
          "fault": {
            "type": "string",
            "enum": [
              "ejected",
              "writeProtected",
              "noIndex",
              "seekFail",
              "unresponsive",
              "badSector",
              "clear"
            ],
            "description": "故障：ejected 取盘（放回时内容不变），writeProtected 写保护，noIndex 无索引脉冲，seekFail 磁头卡住，unresponsive 控制器无响应，badSector 指定扇区校验错，clear 关闭全部故障、放回盘片、取消写保护"
          },
          "enabled": {
            "type": "boolean",
            "description": "打开还是关闭这个故障，默认 true；clear 不用这一项"
          },
          "sector": {
            "type": "integer",
            "minimum": 0,
            "description": "badSector 的逻辑扇区号（磁道×每道扇区数×面数 + 磁头×每道扇区数 + 扇区号 - 1），badSector 必填"
          }
        },
        "required": [
          "drive",
          "fault"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/FloppyStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": [
        "media.noDrive",
        "media.sectorRequired"
      ]
    },
    "printerStatus": {
      "description": "打印机的状态：空闲、打印中、打印完成，当前页是否有内容，已输出的页数与最近一页的文件名；还没有主机或主机没有打印机时为空闲。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/PrinterStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": []
    },
    "printerFlush": {
      "description": "立即输出当前页，等同打印机收到换页；页上的内容画成 PNG 保存到首选项“打印机”里设置的目录，成功后发 media.printed。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/PrinterStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": [
        "media.noMachine",
        "media.noPrinter",
        "media.printerEmpty"
      ]
    },
    "tapeLoad": {
      "description": "把声音文件放进磁带机当磁带（解码交给随应用附带的 ffmpeg，m4a、mp3、wav 等都可以），位置回到开头，替换已有的磁带；磁带机与主机无关，没有主机、没有通电时也可以载入；磁带机播放或录音时不能载入。单声道文件整路是数据线，立体声文件左声道出声、右声道是数据线。",
      "mainOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "path": {
            "type": "string",
            "minLength": 1,
            "description": "声音文件的路径"
          }
        },
        "required": [
          "path"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/TapeStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": [
        "media.tapeBusy",
        "media.fileNotFound",
        "media.fileUnreadable",
        "media.tapeUnsupported",
        "media.decoderMissing"
      ]
    },
    "tapeEject": {
      "description": "取出磁带；没有磁带时没有效果；播放或录音时先停止再取出（录音的文件先写完）。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/TapeStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": []
    },
    "tapePlay": {
      "description": "开始播放；磁带放完后再播放从头开始；已经在播放或录音时没有效果；主机没有通电或没有磁带接口时不能播放。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/TapeStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": [
        "media.noTape",
        "media.tapeNotConnected"
      ]
    },
    "tapeRecord": {
      "description": "放入一盘空白磁带并开始录音：主机送给磁带的 1 位信号按时间记成 32 kHz、单声道、16 位的 WAV 文件（已有的文件被覆盖）；停止后这个文件自动成为磁带机里的磁带，位置在开头，可以直接播放；磁带机播放或录音时不能开始录音；主机没有通电或没有磁带接口时不能录音。",
      "mainOnly": true,
      "params": {
        "type": "object",
        "properties": {
          "path": {
            "type": "string",
            "minLength": 1,
            "description": "录音文件的路径"
          }
        },
        "required": [
          "path"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/TapeStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": [
        "media.tapeBusy",
        "media.tapeNotConnected",
        "media.saveFailed"
      ]
    },
    "tapeStop": {
      "description": "停止播放或录音；录音停止时把录到的内容写完，文件成为磁带机里的磁带；已经停止时没有效果。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/TapeStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": [
        "media.fileUnreadable",
        "media.tapeUnsupported",
        "media.decoderMissing"
      ]
    },
    "tapeStatus": {
      "description": "磁带机的状态；磁带机一直存在，没有接在通电的主机上时 connected 为 false。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/TapeStatus"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": []
    }
  },
  "mainRequests": {
    "openFloppy": {
      "description": "弹出系统文件选择窗口（软盘镜像），把用户选定的文件交给 media.floppyInsert；用户取消选择时 canceled 为 true，不是错误。给出 droppedId 时不弹窗口，直接用拖入窗口的那个文件。",
      "params": {
        "type": "object",
        "properties": {
          "drive": {
            "type": "integer",
            "minimum": 0,
            "maximum": 3,
            "description": "驱动器编号"
          },
          "droppedId": {
            "type": "integer",
            "minimum": 1,
            "description": "拖入窗口的文件的编号（拖放时由主进程登记，路径只在主进程里）；不给时弹出文件选择窗口"
          }
        },
        "required": [
          "drive"
        ]
      },
      "result": {
        "type": "object",
        "properties": {
          "canceled": {
            "type": "boolean",
            "description": "用户是否取消了选择"
          },
          "status": {
            "$ref": "#/types/FloppyStatus",
            "description": "放入盘片后的驱动器状态；取消时没有这一项"
          }
        },
        "required": [
          "canceled"
        ]
      },
      "errors": [
        "media.droppedNotFound",
        "media.noDrive",
        "media.fileNotFound",
        "media.fileUnreadable",
        "media.imageInvalid",
        "media.saveFailed"
      ]
    },
    "openTape": {
      "description": "弹出系统文件选择窗口（声音文件），把用户选定的文件交给 media.tapeLoad；用户取消选择时 canceled 为 true，不是错误。给出 droppedId 时不弹窗口，直接用拖入窗口的那个文件。",
      "params": {
        "type": "object",
        "properties": {
          "droppedId": {
            "type": "integer",
            "minimum": 1,
            "description": "拖入窗口的文件的编号（拖放时由主进程登记，路径只在主进程里）；不给时弹出文件选择窗口"
          }
        },
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "canceled": {
            "type": "boolean",
            "description": "用户是否取消了选择"
          },
          "status": {
            "$ref": "#/types/TapeStatus",
            "description": "放入磁带后的磁带机状态；取消时没有这一项"
          }
        },
        "required": [
          "canceled"
        ]
      },
      "errors": [
        "media.droppedNotFound",
        "media.tapeBusy",
        "media.fileNotFound",
        "media.fileUnreadable",
        "media.tapeUnsupported",
        "media.decoderMissing"
      ]
    },
    "openTapeRecording": {
      "description": "弹出系统的保存文件窗口（WAV 文件），把用户选定的文件交给 media.tapeRecord；用户取消选择时 canceled 为 true，不是错误。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "canceled": {
            "type": "boolean",
            "description": "用户是否取消了选择"
          },
          "status": {
            "$ref": "#/types/TapeStatus",
            "description": "开始录音后的磁带机状态；取消时没有这一项"
          }
        },
        "required": [
          "canceled"
        ]
      },
      "errors": [
        "media.tapeBusy",
        "media.tapeNotConnected",
        "media.saveFailed"
      ]
    }
  },
  "events": {
    "changed": {
      "description": "介质的状态变化：盘片插入、取出、保存、注入故障与马达开关，磁带的载入、取出、播放、录音与停止，磁带机接上或断开主机（connected 变化时随运行状态事件刷新，不另发本事件）。",
      "data": {
        "type": "object",
        "properties": {
          "device": {
            "type": "string",
            "enum": [
              "floppy",
              "tape"
            ],
            "description": "设备"
          },
          "drive": {
            "type": "integer",
            "minimum": 0,
            "description": "驱动器编号；磁带机恒为 0"
          }
        },
        "required": [
          "device",
          "drive"
        ]
      }
    },
    "printed": {
      "description": "打印机输出了一页：已经保存成 PNG 文件。",
      "data": {
        "type": "object",
        "properties": {
          "fileName": {
            "type": "string",
            "description": "文件名，不含路径"
          },
          "page": {
            "type": "integer",
            "minimum": 1,
            "description": "本次运行以来的页序号"
          }
        },
        "required": [
          "fileName",
          "page"
        ]
      }
    },
    "printFailed": {
      "description": "打印机输出的一页无法保存（目录无法写入等），这一页已丢弃。",
      "data": {
        "type": "object",
        "properties": {
          "message": {
            "type": "string",
            "description": "原因，面向用户"
          }
        },
        "required": [
          "message"
        ]
      }
    },
    "floppySaveFailed": {
      "description": "盘片镜像无法自动写回文件（文件被占用、没有写权限等）；修改仍在内存里，核心之后每 5 秒重试一次，写回成功前只通知这一次。",
      "data": {
        "type": "object",
        "properties": {
          "drive": {
            "type": "integer",
            "minimum": 0,
            "description": "驱动器编号"
          },
          "message": {
            "type": "string",
            "description": "原因，面向用户"
          }
        },
        "required": [
          "drive",
          "message"
        ]
      }
    }
  }
};
