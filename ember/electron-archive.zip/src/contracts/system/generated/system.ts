// 由 tools/schema-gen/schema-gen.mjs 根据 schema/system.schema.json 生成，不要手改。
/* eslint-disable */


import type { ModuleSchema } from '../../../shared/schema/schema-types';

/** 应用升级的状态；只由主进程维护。 */
export interface UpdateStatus {
  /** unsupported 当前运行方式不支持升级（开发版、免安装目录、非 Windows），idle 还没有检查过，checking 正在检查，downloading 发现新版本、正在下载，ready 新版本已下载、重启后生效，upToDate 已是最新版本，error 检查或下载失败 */
  state: "unsupported" | "idle" | "checking" | "downloading" | "ready" | "upToDate" | "error";
  /** 新版本的版本号，只在 ready 时有，升级服务器没有给出版本号时没有这一项 */
  version?: string;
  /** 失败的原因，只在 error 时有 */
  message?: string;
}

export type SystemVersionParams = Record<string, never>;

export interface SystemVersionResult {
  /** 应用版本，取自安装包的版本号 */
  appVersion: string;
  /** 核心版本，取自核心的构建参数 */
  coreVersion: string;
}

export type SystemOpenLogDirectoryParams = Record<string, never>;

export type SystemOpenLogDirectoryResult = Record<string, never>;

export interface SystemOpenHelpParams {
  /** 要打开的页面：changelog 更新记录；不传时打开首页，已经打开的窗口不传时不改变当前页 */
  page?: "changelog";
}

export type SystemOpenHelpResult = Record<string, never>;

export type SystemUpdateStatusParams = Record<string, never>;

export interface SystemUpdateStatusResult {
  /** 当前状态 */
  status: UpdateStatus;
}

export type SystemCheckUpdateParams = Record<string, never>;

export interface SystemCheckUpdateResult {
  /** 请求返回时的状态 */
  status: UpdateStatus;
}

export type SystemInstallUpdateParams = Record<string, never>;

export type SystemInstallUpdateResult = Record<string, never>;

/** 本模块的请求名。 */
export const SYSTEM_REQUESTS = {
  version: 'system.version'
} as const;

/** 本模块由主进程处理的请求名。 */
export const SYSTEM_MAIN_REQUESTS = {
  openLogDirectory: 'system.openLogDirectory',
  openHelp: 'system.openHelp',
  updateStatus: 'system.updateStatus',
  checkUpdate: 'system.checkUpdate',
  installUpdate: 'system.installUpdate'
} as const;

/** 本模块的事件名。 */
export const SYSTEM_EVENTS = {

} as const;

/** 请求名到参数与结果类型的对照。 */
export interface SystemRequestMap {
  'system.version': { params: SystemVersionParams; result: SystemVersionResult };
}

/** 主进程处理的请求名到参数与结果类型的对照。 */
export interface SystemMainRequestMap {
  'system.openLogDirectory': { params: SystemOpenLogDirectoryParams; result: SystemOpenLogDirectoryResult };
  'system.openHelp': { params: SystemOpenHelpParams; result: SystemOpenHelpResult };
  'system.updateStatus': { params: SystemUpdateStatusParams; result: SystemUpdateStatusResult };
  'system.checkUpdate': { params: SystemCheckUpdateParams; result: SystemCheckUpdateResult };
  'system.installUpdate': { params: SystemInstallUpdateParams; result: SystemInstallUpdateResult };
}

/** 事件名到数据类型的对照。 */
export type SystemEventMap = Record<never, never>;

/** 本模块的 Schema，供入口校验使用。 */
export const SYSTEM_SCHEMA: ModuleSchema = {
  "module": "system",
  "types": {
    "UpdateStatus": {
      "type": "object",
      "description": "应用升级的状态；只由主进程维护。",
      "properties": {
        "state": {
          "type": "string",
          "enum": [
            "unsupported",
            "idle",
            "checking",
            "downloading",
            "ready",
            "upToDate",
            "error"
          ],
          "description": "unsupported 当前运行方式不支持升级（开发版、免安装目录、非 Windows），idle 还没有检查过，checking 正在检查，downloading 发现新版本、正在下载，ready 新版本已下载、重启后生效，upToDate 已是最新版本，error 检查或下载失败"
        },
        "version": {
          "type": "string",
          "minLength": 1,
          "description": "新版本的版本号，只在 ready 时有，升级服务器没有给出版本号时没有这一项"
        },
        "message": {
          "type": "string",
          "minLength": 1,
          "description": "失败的原因，只在 error 时有"
        }
      },
      "required": [
        "state"
      ]
    }
  },
  "requests": {
    "version": {
      "description": "返回应用版本与核心版本。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "appVersion": {
            "type": "string",
            "minLength": 1,
            "description": "应用版本，取自安装包的版本号"
          },
          "coreVersion": {
            "type": "string",
            "minLength": 1,
            "description": "核心版本，取自核心的构建参数"
          }
        },
        "required": [
          "appVersion",
          "coreVersion"
        ]
      }
    }
  },
  "mainRequests": {
    "openLogDirectory": {
      "description": "用系统的文件管理器打开日志目录（目录不存在时先创建）；路径由主进程决定，界面不能指定。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": [
        "system.logDirectoryUnavailable"
      ]
    },
    "openHelp": {
      "description": "在应用内弹出帮助文档窗口（已经打开时提到最前）；文档是随应用带的静态页面，位置由主进程决定，界面不能指定，只能从固定的几页里选。",
      "params": {
        "type": "object",
        "properties": {
          "page": {
            "type": "string",
            "enum": [
              "changelog"
            ],
            "description": "要打开的页面：changelog 更新记录；不传时打开首页，已经打开的窗口不传时不改变当前页"
          }
        },
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": [
        "system.helpUnavailable"
      ]
    },
    "updateStatus": {
      "description": "读取应用升级的当前状态；状态变化时主进程另外推送给界面。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/UpdateStatus",
            "description": "当前状态"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": []
    },
    "checkUpdate": {
      "description": "开始检查更新；有新版本时自动下载。请求在开始检查后立即返回当前状态，检查与下载的进展经状态推送给界面；正在检查、正在下载、已经下载好或不支持升级时不重复检查，直接返回当前状态。升级服务器的地址写在主进程里，界面不能指定。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {
          "status": {
            "$ref": "#/types/UpdateStatus",
            "description": "请求返回时的状态"
          }
        },
        "required": [
          "status"
        ]
      },
      "errors": []
    },
    "installUpdate": {
      "description": "重启应用并使用已经下载好的新版本；只在状态为 ready 时可用。应用先走正常的退出流程（保存界面状态、停止核心），再重新启动。",
      "params": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "result": {
        "type": "object",
        "properties": {},
        "required": []
      },
      "errors": [
        "system.updateNotReady"
      ]
    }
  },
  "events": {}
};
