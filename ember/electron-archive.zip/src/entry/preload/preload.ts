/*
 * ------------------------------------------------------------------------
 * 名称：preload.ts
 * 说明：预加载脚本：向界面暴露 window.ember，界面可发起的核心请求与主进程请求按 Schema 生成的请求名暴露为“模块.操作”的具名方法，另有接收画面与输入端口的方法，以及外壳自己的能力（界面状态的保存、窗口动作、拖入文件的登记）。
 * 作者：sungbin
 * 邮箱：sungbin@3578.cn
 * 日期：2026-11-13
 * 备注：不暴露 ipcRenderer 与通用的调用入口；回调只收到数据，不收到 IPC 事件对象；核心请求失败时以 {code, message} 拒绝。
 *       端口：页面调用 streams.requestPorts() 后，主进程把两个 MessagePort 发给本脚本；本脚本确认标记与端口数量后，
 *       用 window.postMessage 把端口交给页面（上下文隔离下 contextBridge 无法传递端口），页面须检查 event.source 是自己的窗口。
 * ------------------------------------------------------------------------
 */

import { contextBridge, ipcRenderer, webUtils, type IpcRendererEvent } from 'electron';
import { CORE_REQUEST_NAMES, MAIN_REQUEST_NAMES, type CoreApi, type MainApi } from '../../contracts/core-gateway/generated/core-api';
import type { DroppedFile } from '../../contracts/shell/dropped-files';
import { SHELL_CHANNELS, type CoreRequestReply, type EmberBridge, type ShellBridge } from '../../contracts/shell/shell-bridge';
import { STREAM_PORTS_WINDOW_MESSAGE, type StreamPortsWindowMessage } from '../../contracts/stream-ports/stream-messages';
import { STREAM_CHANNELS, type StreamPortsBridge } from '../../contracts/stream-ports/stream-ports';

/** 主进程交给页面的端口个数：画面端口与输入端口。 */
const STREAM_PORT_COUNT = 2;

/** 订阅主进程推送的消息，返回取消订阅的函数。 */
function subscribe<T extends unknown[]>(channel: string, listener: (...args: T) => void): () => void {
  const handler = (_event: IpcRendererEvent, ...args: unknown[]): void => listener(...(args as T));
  ipcRenderer.on(channel, handler);
  return () => {
    ipcRenderer.removeListener(channel, handler);
  };
}

/** 发送一次请求。 */
async function request(channel: string, name: string, params: unknown): Promise<unknown> {
  const reply = (await ipcRenderer.invoke(channel, name, params)) as CoreRequestReply;
  if (reply.ok) return reply.result;
  // Error 经 contextBridge 复制时会丢失 code 等自定义属性，所以以普通对象拒绝。
  throw { code: reply.error.code, message: reply.error.message };
}

/** 按请求名生成按模块分组的具名方法。 */
function buildApi(names: readonly string[], channel: string): Record<string, Record<string, (params: unknown) => Promise<unknown>>> {
  const api: Record<string, Record<string, (params: unknown) => Promise<unknown>>> = {};
  for (const name of names) {
    const dot = name.indexOf('.');
    const module = name.slice(0, dot);
    const operation = name.slice(dot + 1);
    api[module] ??= {};
    api[module][operation] = (params) => request(channel, name, params);
  }
  return api;
}

/** 主进程发来端口：标记与数量都对才交给页面，否则丢弃。 */
ipcRenderer.on(STREAM_CHANNELS.ports, (event: IpcRendererEvent, tag: unknown) => {
  if (tag !== STREAM_PORTS_WINDOW_MESSAGE || event.ports.length !== STREAM_PORT_COUNT) return;
  const message: StreamPortsWindowMessage = { type: STREAM_PORTS_WINDOW_MESSAGE };
  // file 页面的源是 "null"，不能作为目标源；这时消息只发给本窗口自己，用 "*" 即可。
  const targetOrigin = window.location.origin === 'null' ? '*' : window.location.origin;
  window.postMessage(message, targetOrigin, [...event.ports]);
});

const streams: StreamPortsBridge = {
  requestPorts: () => ipcRenderer.send(STREAM_CHANNELS.connect)
};

const shell: ShellBridge = {
  getState: () => ipcRenderer.invoke(SHELL_CHANNELS.getState),
  setLayout: (patch) => ipcRenderer.send(SHELL_CHANNELS.setLayout, patch),
  windowAction: (action) => ipcRenderer.send(SHELL_CHANNELS.windowAction, action),
  getWindowState: () => ipcRenderer.invoke(SHELL_CHANNELS.getWindowState),
  onWindowStateChange: (listener) => subscribe(SHELL_CHANNELS.windowStateChanged, listener),
  setKeyboardCapture: (enabled) => ipcRenderer.invoke(SHELL_CHANNELS.setKeyboardCapture, enabled),
  onNativeKey: (listener) => subscribe(SHELL_CHANNELS.nativeKey, listener),
  onKeyboardReleased: (listener) => subscribe(SHELL_CHANNELS.keyboardReleased, listener),
  registerDroppedFiles: async (files) => {
    // 路径只能由这里从真实的文件对象取得，页面不能自己填；不是磁盘文件（没有路径）的会被略过。
    const paths = files.map((file) => webUtils.getPathForFile(file)).filter((path) => path !== '');
    if (paths.length === 0) return [];
    return (await ipcRenderer.invoke(SHELL_CHANNELS.registerDroppedFiles, paths)) as readonly DroppedFile[];
  }
};

const bridge: EmberBridge = {
  core: buildApi(CORE_REQUEST_NAMES, SHELL_CHANNELS.coreRequest) as unknown as CoreApi,
  main: buildApi(MAIN_REQUEST_NAMES, SHELL_CHANNELS.mainRequest) as unknown as MainApi,
  streams,
  shell,
  onCoreEvent: (listener) => subscribe(SHELL_CHANNELS.coreEvent, listener),
  getCoreStatus: () => ipcRenderer.invoke(SHELL_CHANNELS.coreStatus),
  onCoreStatusChange: (listener) => subscribe(SHELL_CHANNELS.coreStatusChanged, listener),
  onUpdateStatusChange: (listener) => subscribe(SHELL_CHANNELS.updateStatusChanged, listener)
};

contextBridge.exposeInMainWorld('ember', bridge);
