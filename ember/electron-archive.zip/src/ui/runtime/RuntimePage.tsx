/*
 * ------------------------------------------------------------------------
 * 名称：RuntimePage.tsx
 * 说明：显示区的内容（运行模块的画面）：显示区里居中放一个按显示比例缩放的画面框（不变形，剩余的地方是页面底色），没有开机、断电、暂停时在画面上覆盖提示；画面区可聚焦，显示时自动聚焦，键盘事件采集后经输入端口送给核心。
 * 作者：sungbin
 * 邮箱：sungbin@3578.cn
 * 日期：2026-11-15
 * 备注：由外壳的显示区挂载（登记在 runtime-module.tsx），机器的信息与控制在底部面板的“运行”页签（RuntimePanel）；画面比例、缩放方式与“显示全部 240 行”取自首选项（use-display-settings.ts），改后立即生效。
 *       必须放在组件库根组件 UiProvider 之内（通知需要它）。
 * ------------------------------------------------------------------------
 */

import { useEffect, useMemo, useRef, type CSSProperties } from 'react';
import type { ShellPageProps } from '../shell/shell-registry';
import type { RuntimeController } from './runtime-controller';
import { RuntimeScreen } from './RuntimeScreen';
import { capturesMouse, machineState } from './runtime-status';
import { cropLinesFor, nominalScreenRatio } from './screen-layout';
import { ScreenOverlay } from './ScreenOverlay';
import { useDisplaySettings } from './use-display-settings';
import { useRuntimeState } from './use-runtime-state';
import { useTimedVisible } from './use-timed-visible';
import './ember-run.css';

/** 用户可见的文字。 */
const TEXT = {
  captureHint: '点击画面捕获鼠标，双击右键释放'
} as const;

/** 捕获鼠标的提示显示几秒后消失，不一直遮挡画面。 */
const CAPTURE_HINT_MS = 4000;

/** 运行页的属性。 */
export interface RuntimePageProps extends ShellPageProps {
  readonly controller: RuntimeController;
}

/**
 * 运行页。
 * @param props 属性。
 */
export function RuntimePage({ bridge, controller }: RuntimePageProps) {
  const screenRef = useRef<HTMLDivElement>(null);
  const { aspect, scaling, showAllLines, captureMouse } = useDisplaySettings(bridge);
  const { status } = useRuntimeState(controller);
  // 只有机器带鼠标（整机机型，经典 FC 没有）时才捕获鼠标。
  const capture = capturesMouse(captureMouse, status);
  const showHint = useTimedVisible(capture && machineState(status) !== 'none' && machineState(status) !== 'off', CAPTURE_HINT_MS);
  // 画面框的样式：显示宽高比交给样式里的 aspect-ratio 与宽度计算；比例随画面比例与裁剪的行数变化。
  const frameStyle = useMemo(() => ({ '--ember-screen-ratio': nominalScreenRatio(aspect, cropLinesFor(showAllLines)) }) as CSSProperties, [aspect, showAllLines]);
  // 运行面板里的操作结束后，控制器经它把焦点还给画面，键盘才能继续控制游戏。
  useEffect(() => {
    controller.setScreenFocus(() => screenRef.current?.focus({ preventScroll: true }));
    return () => controller.setScreenFocus(undefined);
  }, [controller]);
  return (
    <div className="ember-run">
      <div className="ember-run-stage">
        <div className="ember-run-frame" style={frameStyle}>
          <RuntimeScreen bridge={bridge} screenRef={screenRef} aspect={aspect} scaling={scaling} showAllLines={showAllLines} captureMouse={capture} />
          <ScreenOverlay controller={controller} />
          {showHint ? <div className="ember-run-hint">{TEXT.captureHint}</div> : null}
        </div>
      </div>
    </div>
  );
}
